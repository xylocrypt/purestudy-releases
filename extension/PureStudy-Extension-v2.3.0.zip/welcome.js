(function () {
  "use strict";

  const ua = navigator.userAgent || "";
  const isEdge = /\bEdg\//.test(ua);
  const browserName = isEdge ? "Edge" : "Chrome";
  const extensionsUrl = isEdge ? "edge://extensions" : "chrome://extensions";

  const status = document.getElementById("status");
  const statusText = document.getElementById("statusText");
  const kicker = document.getElementById("kicker");
  const openButton = document.getElementById("openApp");
  const openSettingsButton = document.getElementById("openSettings");
  const checkButton = document.getElementById("checkAgain");
  const copyButton = document.getElementById("copyUrl");
  const version = document.getElementById("version");

  let checking = false;

  document.querySelectorAll("[data-browser-name]").forEach(function (element) {
    element.textContent = browserName;
  });

  document.querySelectorAll("#extensionsUrl").forEach(function (element) {
    element.textContent = extensionsUrl;
  });

  try {
    const manifest = chrome.runtime.getManifest();
    if (manifest && manifest.version) version.textContent = manifest.version;
  } catch (error) {
    // Keep the static version fallback.
  }

  function setStatus(kind, text) {
    status.classList.remove("ok");
    if (kind === "ok") status.classList.add("ok");
    statusText.textContent = text;
  }

  function setPinnedState(pinned) {
    document.body.classList.toggle("pinned", pinned);
    kicker.textContent = pinned ? "Pinned" : "Installed";
  }

  async function readPinState() {
    if (!chrome.action || typeof chrome.action.getUserSettings !== "function") {
      return { supported: false, pinned: false };
    }

    try {
      const settings = await chrome.action.getUserSettings();
      return { supported: true, pinned: Boolean(settings && settings.isOnToolbar) };
    } catch (error) {
      return { supported: false, pinned: false };
    }
  }

  async function refresh(silent) {
    if (checking) return;
    checking = true;

    if (!silent) setStatus("checking", "Checking whether PureStudy is pinned…");

    const result = await readPinState();
    checking = false;

    if (!result.supported) {
      setPinnedState(false);
      setStatus("unknown", "Pin status can’t be checked automatically — use the steps below.");
      return;
    }

    if (result.pinned) {
      setPinnedState(true);
      setStatus("ok", "Pinned to your toolbar — you’re all set.");
    } else {
      setPinnedState(false);
      setStatus("waiting", "Not pinned yet — PureStudy is in the extensions menu.");
    }
  }

  async function openApp() {
    const originalLabel = openButton.textContent;
    openButton.disabled = true;
    openButton.textContent = "Opening…";

    try {
      const response = await chrome.runtime.sendMessage({ type: "purestudy:open-app" });
      if (!response || !response.ok) throw new Error("The background page did not open the app.");
    } catch (error) {
      try {
        const tab = await chrome.tabs.create({ url: chrome.runtime.getURL("app.html") });
        if (tab && Number.isInteger(tab.id)) {
          await chrome.storage.session.set({ purestudyAppTabId: tab.id });
        }
      } catch (fallbackError) {
        openButton.disabled = false;
        openButton.textContent = originalLabel;
        setStatus("unknown", "Could not open the app. Please try again.");
        return;
      }
    }

    openButton.disabled = false;
    openButton.textContent = originalLabel;
  }

  async function openExtensionSettings() {
    const settingsUrl = extensionsUrl + "/?id=" + chrome.runtime.id;

    try {
      await chrome.tabs.create({ url: settingsUrl });
    } catch (error) {
      setStatus("unknown", "Could not open the settings page. Copy the link below and paste it into the address bar.");
      copyExtensionsLink();
    }
  }

  async function copyExtensionsLink() {
    const originalLabel = copyButton.textContent;

    try {
      await navigator.clipboard.writeText(extensionsUrl);
    } catch (error) {
      const helper = document.createElement("textarea");
      helper.value = extensionsUrl;
      helper.setAttribute("readonly", "");
      helper.style.position = "fixed";
      helper.style.left = "-9999px";
      document.body.appendChild(helper);
      helper.select();
      document.execCommand("copy");
      helper.remove();
    }

    copyButton.textContent = "Copied!";
    window.setTimeout(function () {
      copyButton.textContent = originalLabel;
    }, 1600);
  }

  openButton.addEventListener("click", openApp);
  openSettingsButton.addEventListener("click", openExtensionSettings);
  copyButton.addEventListener("click", copyExtensionsLink);
  checkButton.addEventListener("click", function () {
    refresh(false);
  });

  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") refresh(true);
  });

  refresh(false);
  window.setInterval(function () {
    refresh(true);
  }, 1400);
})();
