const APP_PATH = "app.html";
const TAB_KEY = "purestudyAppTabId";
const TIMER_KEY = "purestudyActiveTimer";
const TIMER_ALARM = "purestudyTimerEnd";
const NOTIFICATION_ID = "purestudyTimerDone";
const APP_MODES = new Set(["work", "short", "long"]);

async function getAppTabInfo() {
  const stored = await chrome.storage.session.get(TAB_KEY);
  const tabId = stored[TAB_KEY];

  if (!Number.isInteger(tabId)) return null;

  try {
    const tab = await chrome.tabs.get(tabId);
    return tab || null;
  } catch (error) {
    await chrome.storage.session.remove(TAB_KEY);
    return null;
  }
}

async function clearDoneSignals() {
  try {
    await chrome.notifications.clear(NOTIFICATION_ID);
  } catch (error) {
    // Notifications can be unavailable if the user denied the permission.
  }

  try {
    await chrome.action.setBadgeText({ text: "" });
  } catch (error) {
    // Badge updates are best-effort.
  }
}

async function openApp() {
  await clearDoneSignals();

  const stored = await chrome.storage.session.get(TAB_KEY);
  const tabId = stored[TAB_KEY];

  if (Number.isInteger(tabId)) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab) {
        await chrome.tabs.update(tabId, { active: true });
        if (Number.isInteger(tab.windowId)) {
          await chrome.windows.update(tab.windowId, { focused: true });
        }
        return;
      }
    } catch (error) {
      await chrome.storage.session.remove(TAB_KEY);
    }
  }

  const tab = await chrome.tabs.create({
    url: chrome.runtime.getURL(APP_PATH)
  });

  if (tab && Number.isInteger(tab.id)) {
    await chrome.storage.session.set({ [TAB_KEY]: tab.id });
  }
}

async function openWelcome() {
  await chrome.tabs.create({
    url: chrome.runtime.getURL("welcome.html")
  });
}

async function scheduleTimer(timer) {
  const when = Number(timer && timer.endAt);
  if (!Number.isFinite(when) || when <= Date.now()) return;

  const existing = await chrome.alarms.get(TIMER_ALARM);
  if (existing && Math.abs(existing.scheduledTime - when) < 1000) return;

  await chrome.alarms.create(TIMER_ALARM, { when });
}

async function clearTimer() {
  await chrome.storage.local.remove(TIMER_KEY);
  await chrome.alarms.clear(TIMER_ALARM);
  await clearDoneSignals();
}

async function notifyTimerDone(timer) {
  const isWork = timer.mode === "work";
  const title = isWork ? "PureStudy · Focus complete" : "PureStudy · Break over";
  const message = isWork
    ? "Focus block complete. Open PureStudy to collect your XP and take a break."
    : "Break's over. Open PureStudy when you're ready for another focus block.";

  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
    await chrome.action.setBadgeText({ text: "!" });
  } catch (error) {
    // Badge updates are best-effort.
  }

  try {
    await chrome.notifications.create(NOTIFICATION_ID, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title,
      message,
      priority: 1,
      requireInteraction: false
    });
  } catch (error) {
    console.error("PureStudy: could not show the timer notification.", error);
  }
}

async function handleTimerEnd() {
  const stored = await chrome.storage.local.get(TIMER_KEY);
  const timer = stored[TIMER_KEY];

  if (!timer || !Number.isFinite(Number(timer.endAt))) return;

  // An alarm can fire a little early after a clock change. Let the session
  // keep its original end time.
  if (Number(timer.endAt) > Date.now() + 1000) {
    await scheduleTimer(timer);
    return;
  }

  // If the app tab is open, the app's own timer will finish the session and
  // send the completion message. Avoid a duplicate notification.
  const appTab = await getAppTabInfo();
  if (appTab && !appTab.discarded) return;

  await chrome.storage.local.remove(TIMER_KEY);
  await notifyTimerDone(timer);
}

async function restoreTimer() {
  const stored = await chrome.storage.local.get(TIMER_KEY);
  const timer = stored[TIMER_KEY];

  if (!timer || !Number.isFinite(Number(timer.endAt))) return;
  if (Number(timer.endAt) > Date.now()) {
    await scheduleTimer(timer);
    return;
  }

  await handleTimerEnd();
}

async function handleTimerStart(message) {
  const endAt = Number(message.endAt);
  if (!Number.isFinite(endAt) || endAt <= Date.now()) return;

  const timer = {
    endAt,
    mode: APP_MODES.has(message.mode) ? message.mode : "work",
    sessionId: String(message.sessionId || "")
  };

  await chrome.storage.local.set({ [TIMER_KEY]: timer });
  await clearDoneSignals();
  await scheduleTimer(timer);
}

async function handleTimerCancel(message) {
  const stored = await chrome.storage.local.get(TIMER_KEY);
  const timer = stored[TIMER_KEY];
  const sessionId = String(message.sessionId || "");

  if (!timer || !sessionId || !timer.sessionId || timer.sessionId === sessionId) {
    await clearTimer();
  }
}

async function handleTimerComplete(message) {
  const stored = await chrome.storage.local.get(TIMER_KEY);
  const timer = stored[TIMER_KEY];
  const sessionId = String(message.sessionId || "");

  if (!timer || !sessionId || !timer.sessionId || timer.sessionId === sessionId) {
    await clearTimer();
  } else {
    await clearDoneSignals();
  }
}

async function handleTimerVisit() {
  // The app is open, so any "session finished while you were away" badge or
  // notification has served its purpose. Keep any active timer untouched.
  await clearDoneSignals();
}

chrome.action.onClicked.addListener(() => {
  openApp().catch(error => {
    console.error("PureStudy: could not open the app tab.", error);
  });
});

chrome.runtime.onInstalled.addListener(details => {
  const reason = details.reason;
  if (reason !== "install" && reason !== "update") return;

  (async () => {
    let pinned = false;

    try {
      const settings = await chrome.action.getUserSettings();
      pinned = Boolean(settings && settings.isOnToolbar);
    } catch (error) {
      // If the browser can't report the pin state, show the pin guide rather
      // than dropping the user into an app with no visible toolbar icon.
    }

    if (!pinned) {
      // This also catches existing installs that never pinned the icon, so an
      // update surfaces the fix instead of leaving them stuck.
      await openWelcome();
    } else if (reason === "install") {
      await openApp();
    }
  })().catch(error => {
    console.error("PureStudy: could not open the first-run page.", error);
  });
});

chrome.runtime.onStartup.addListener(() => {
  restoreTimer().catch(error => {
    console.error("PureStudy: could not restore the timer.", error);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return;

  if (message.type === "purestudy:open-app") {
    openApp()
      .then(() => sendResponse({ ok: true }))
      .catch(error => {
        console.error("PureStudy: could not open the app tab.", error);
        sendResponse({ ok: false });
      });
    return true;
  }

  if (message.type === "purestudy:timer-start") {
    handleTimerStart(message).catch(error => {
      console.error("PureStudy: could not schedule the timer.", error);
    });
    return;
  }

  if (message.type === "purestudy:timer-cancel") {
    handleTimerCancel(message).catch(error => {
      console.error("PureStudy: could not cancel the timer.", error);
    });
    return;
  }

  if (message.type === "purestudy:timer-complete") {
    handleTimerComplete(message).catch(error => {
      console.error("PureStudy: could not clear the timer.", error);
    });
    return;
  }

  if (message.type === "purestudy:timer-visit") {
    handleTimerVisit().catch(error => {
      console.error("PureStudy: could not clear the timer badge.", error);
    });
  }
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== TIMER_ALARM) return;
  handleTimerEnd().catch(error => {
    console.error("PureStudy: timer alarm failed.", error);
  });
});

chrome.notifications.onClicked.addListener(notificationId => {
  if (notificationId !== NOTIFICATION_ID) return;
  openApp().catch(error => {
    console.error("PureStudy: could not open the app from the notification.", error);
  });
});

chrome.tabs.onRemoved.addListener(async tabId => {
  try {
    const stored = await chrome.storage.session.get(TAB_KEY);
    if (stored[TAB_KEY] === tabId) {
      await chrome.storage.session.remove(TAB_KEY);
    }
  } catch (error) {
    // A stale tab id is harmless; openApp checks that the tab still exists.
  }
});
