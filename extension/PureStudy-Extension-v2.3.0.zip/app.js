(() => {
  "use strict";

  /* ============================ state ============================ */
  const KEY = "focusstudy.v1";
  const APP_VERSION = "2.3.0";
  const FEEDBACK_REPO = "https://github.com/xylocrypt/purestudy-releases";
  const CIRC = 2 * Math.PI * 126;

  const TREAT_TYPES = {
    fish:   { icon: "🐟", one: "fish",         many: "fish" },
    carrot: { icon: "🥕", one: "carrot",       many: "carrots" },
    bamboo: { icon: "🎋", one: "bamboo shoot", many: "bamboo shoots" },
    fly:    { icon: "🪰", one: "fly",          many: "flies" },
    bone:   { icon: "🦴", one: "bone",         many: "bones" }
  };
  const TODO_PRIORITIES = {
    low:    { label: "Low" },
    normal: { label: "Normal" },
    high:   { label: "High" }
  };
  const NEXT_PRIORITY = { normal: "high", high: "low", low: "normal" };

  const PET_VARIANTS = [
    { id: "ophi",   name: "Ophilia", kind: "Cat",         treat: "fish",   fur: "#f6d3a0", shade: "#f3c98b", belly: "#ffe9c7", inner: "#f7a8b8", ear: "cat",     tail: "cat",     face: "cat" },
    { id: "glbani", name: "Glbani",  kind: "Special cat", treat: "fish",   fur: "#f4f4ef", shade: "#e2e2dc", belly: "#ffffff", inner: "#f0bac4", ear: "cat",     tail: "cat",     face: "glbani", patch: "#3e444b", special: true },
    { id: "mochi",  name: "Mochi",   kind: "Bunny",       treat: "carrot", fur: "#f8f1e8", shade: "#e7dbcd", belly: "#fffaf4", inner: "#f3b8c6", ear: "bunny",   tail: "bunny",   face: "bunny" },
    { id: "biscuit",name: "Biscuit", kind: "Dog",         treat: "bone",   fur: "#dca56d", shade: "#c98f57", belly: "#f7d9b8", inner: "#d98b79", ear: "dog",     tail: "dog",     face: "dog",     patch: "#8a5b39" },
    { id: "pepper", name: "Pepper",  kind: "Fox",         treat: "fish",   fur: "#e98b4c", shade: "#d9783a", belly: "#fff1df", inner: "#f4a7a0", ear: "fox",     tail: "fox",     face: "fox" },
    { id: "luna",   name: "Luna",    kind: "Panda",       treat: "bamboo", fur: "#f5f5f1", shade: "#e3e3dc", belly: "#ffffff", inner: "#4a5057", ear: "panda",   tail: "panda",   face: "panda",   patch: "#343a40" },
    { id: "tofu",   name: "Tofu",    kind: "Hamster",     treat: "carrot", fur: "#ebcb98", shade: "#d9b173", belly: "#fff1d4", inner: "#e9a7a7", ear: "hamster", tail: "hamster", face: "hamster" },
    { id: "clover", name: "Clover",  kind: "Frog",        treat: "fly",    fur: "#82cc8c", shade: "#65b474", belly: "#dff6d7", inner: "#7fb47f", ear: "frog",    tail: "none",    face: "frog" }
  ];

  const todayKey = (d = new Date()) => {
    const p = n => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  };
  const dayOffset = k => {
    const [y, m, d] = k.split("-").map(Number);
    return new Date(y, m - 1, d);
  };
  const daysBetween = (a, b) =>
    Math.round((dayOffset(b) - dayOffset(a)) / 86400000);

  function cleanName(value) {
    const flat = String(value == null ? "" : value)
      .replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return Array.from(flat).slice(0, 24).join("");
  }

  function cleanTodo(value) {
    const flat = String(value == null ? "" : value)
      .replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return Array.from(flat).slice(0, 120).join("");
  }

  function cleanExam(value) {
    const flat = String(value == null ? "" : value)
      .replace(/[\u0000-\u001f\u007f]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return Array.from(flat).slice(0, 40).join("");
  }

  function validExamDate(value) {
    const raw = String(value || "").slice(0, 10);
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
    if (!m) return "";
    const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    if (d.getFullYear() !== Number(m[1]) || d.getMonth() !== Number(m[2]) - 1 || d.getDate() !== Number(m[3])) return "";
    return raw;
  }

  function newTodoId() {
    return "t" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function normalizeTodos(value) {
    if (!Array.isArray(value)) return [];
    const out = [];
    const used = new Set();
    for (const item of value) {
      if (!item || typeof item !== "object") continue;
      const text = cleanTodo(item.text);
      if (!text) continue;
      let id = typeof item.id === "string" ? item.id.replace(/[^a-z0-9]/gi, "").slice(0, 24) : "";
      if (!id || used.has(id)) id = newTodoId();
      used.add(id);
      const priority = TODO_PRIORITIES[item.priority] ? item.priority : "normal";
      const focusMinutes = Math.max(0, Math.min(100000, Math.round(Number(item.focusMinutes) || 0)));
      out.push({ id, text, done: item.done === true, priority, focusMinutes });
      if (out.length >= 30) break;
    }
    return out;
  }

  const mapDefaults = () => ({
    nextId: 5,
    nextNoteId: 1,
    notes: [],
    nodes: [
      { id: 1, text: "Today's topic", x: 0, y: 0, parent: null },
      { id: 2, text: "What I know", x: -115, y: -115, parent: 1 },
      { id: 3, text: "What's unclear", x: 115, y: -115, parent: 1 },
      { id: 4, text: "Next small step", x: 0, y: 150, parent: 1 }
    ]
  });

  const defaults = () => ({
    settings: { work: 25, short: 5, long: 15, blocks: 3, auto: true, sound: true, soundStyle: "chime", volume: 70, dailyGoal: 3, buddy: true, musicVolume: 45, theme: "dark", accent: "mint", accentCustom: "#4ade80", logo: "clock-mint", name: "", pet: "ophi", petNames: {}, examName: "", examDate: "", onboarded: false },
    stats: {
      xp: 0, totalSessions: 0, totalMinutes: 0, treats: 0, fed: 0,
      todayDate: todayKey(), todayMinutes: 0, todayXp: 0, todaySessions: 0,
      streak: 0, bestStreak: 0, lastDate: null,
      week: {} // "YYYY-MM-DD": minutes
    },
    task: "",
    todos: [],
    focusTask: null,
    journal: [],
    mindmap: mapDefaults(),
    timer: { mode: "work", remaining: 25 * 60, running: false, blocksDone: 0, endAt: 0, sessionId: "" }
  });

  let S;
  let skipUnloadSave = false;
  let storedState = null;
  try {
    const rawState = localStorage.getItem(KEY);
    storedState = rawState ? JSON.parse(rawState) : null;
    S = deepMerge(defaults(), storedState || {});
  } catch (e) {
    S = defaults();
  }

  // Profiles saved before the welcome screen are already set up. A new profile
  // (or one saved mid-welcome with onboarded:false) still gets the setup flow.
  if (storedState && storedState.settings && typeof storedState.settings === "object" && storedState.settings.onboarded === undefined) {
    S.settings.onboarded = true;
  } else {
    S.settings.onboarded = S.settings.onboarded === true;
  }
  S.settings.name = cleanName(S.settings.name);
  S.settings.examName = cleanExam(S.settings.examName);
  S.settings.examDate = validExamDate(S.settings.examDate);
  if (!PET_VARIANTS.some(p => p.id === S.settings.pet)) S.settings.pet = "ophi";
  if (!S.settings.petNames || typeof S.settings.petNames !== "object" || Array.isArray(S.settings.petNames)) {
    S.settings.petNames = {};
  }
  for (const id of Object.keys(S.settings.petNames)) {
    const fixed = cleanName(S.settings.petNames[id]);
    if (PET_VARIANTS.some(p => p.id === id) && fixed) S.settings.petNames[id] = fixed;
    else delete S.settings.petNames[id];
  }

  const legacyTask = cleanTodo(S.task);
  S.todos = normalizeTodos(S.todos);
  if (!S.todos.length && legacyTask) {
    S.todos.push({ id: newTodoId(), text: legacyTask, done: false, priority: "normal", focusMinutes: 0 });
  }
  S.task = "";
  if (!S.todos.some(t => t.id === S.focusTask && !t.done)) S.focusTask = null;

  function deepMerge(base, over) {
    const out = Array.isArray(base) ? base.slice() : { ...base };
    if (!over || typeof over !== "object") return out;
    for (const k of Object.keys(over)) {
      if (k === "__proto__" || k === "constructor" || k === "prototype") continue;
      const v = over[k];
      if (v && typeof v === "object" && !Array.isArray(v) && base[k] && typeof base[k] === "object" && !Array.isArray(base[k])) {
        out[k] = deepMerge(base[k], v);
      } else if (v !== undefined) {
        out[k] = v;
      }
    }
    return out;
  }

  const save = () => {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {}
  };

  const rollDay = () => {
    const t = todayKey();
    if (S.stats.todayDate !== t) {
      S.stats.todayDate = t;
      S.stats.todayMinutes = 0;
      S.stats.todayXp = 0;
      S.stats.todaySessions = 0;
    }
    // a streak only survives if the last study day was today or yesterday
    if (S.stats.lastDate) {
      const gap = daysBetween(S.stats.lastDate, t);
      if (gap > 1) S.stats.streak = 0;
    }
  };

  /* ============================ dom ============================ */
  const $ = id => document.getElementById(id);
  const el = {
    modeLabel: $("modeLabel"), time: $("time"), sub: $("sub"), ring: $("ring"),
    cycles: $("cycles"), startBtn: $("startBtn"), resetBtn: $("resetBtn"), skipBtn: $("skipBtn"),
    focusTask: $("focusTask"), focusTaskName: $("focusTaskName"), focusTaskClear: $("focusTaskClear"),
    todoForm: $("todoForm"), todoInput: $("todoInput"), todoList: $("todoList"),
    todoCount: $("todoCount"), todoEmpty: $("todoEmpty"), todoClear: $("todoClear"),
    greeting: $("greeting"), greetName: $("greetName"), greetLine: $("greetLine"),
    examBadge: $("examBadge"), examBadgeText: $("examBadgeText"),
    coachText: $("coachText"), coachNext: $("coachNext"), coachPick: $("coachPick"),
    setName: $("setName"),
    todayMin: $("todayMin"), todayXp: $("todayXp"),
    momentum: $("momentum"), goalText: $("focusGoalText"), goalCount: $("focusGoalCount"), goalBar: $("focusGoalBar"),
    goalFrac: $("goalFrac"), goalBar2: $("goalBar2"), goalHint: $("goalHint"),
    buddyCard: $("buddyCard"), buddyLine: $("buddyLine"), bondText: $("bondText"),
    treatText: $("treatText"), feedBtn: $("feedBtn"),
    petBtn: $("petBtn"), petSvg: $("petSvg"), petNameLabel: $("petNameLabel"), petHearts: $("petHearts"), miniBtn: $("miniBtn"),
    petSign: $("petSign"), petSignDays: $("petSignDays"), petSignLabel: $("petSignLabel"),
    petGrid: $("petGrid"), setPetName: $("setPetName"),
    setExamName: $("setExamName"), setExamDate: $("setExamDate"), examClear: $("examClear"),
    exportBackup: $("exportBackup"), importBackup: $("importBackup"), importFile: $("importFile"),
    lvlPill: $("lvlPill"), streakPill: $("streakPill"),
    lvlNum: $("lvlNum"), xpText: $("xpText"), xpBar: $("xpBar"),
    sStreak: $("sStreak"), sBest: $("sBest"), sSessions: $("sSessions"), sMinutes: $("sMinutes"),
    weekChart: $("weekChart"), weekLabels: $("weekLabels"),
    journalInput: $("journalInput"), journalAdd: $("journalAdd"), journalList: $("journalList"),
    setWork: $("setWork"), setShort: $("setShort"), setLong: $("setLong"),
    setBlocks: $("setBlocks"), setGoal: $("setGoal"), setAuto: $("setAuto"), setSound: $("setSound"),
    setSoundStyle: $("setSoundStyle"), setVolume: $("setVolume"), volText: $("volText"),
    setBuddy: $("setBuddy"), testSound: $("testSound"),
    feedbackKinds: document.querySelectorAll(".feedback-kind"),
    feedbackTitle: $("feedbackTitle"), feedbackText: $("feedbackText"),
    feedbackInclude: $("feedbackInclude"), feedbackSend: $("feedbackSend"),
    feedbackCopy: $("feedbackCopy"), feedbackLink: $("feedbackLink"),
    musicVol: $("musicVol"), musicVolText: $("musicVolText"), musicNow: $("musicNow"),
    musicDot: $("musicDot"), musicStop: $("musicStop"),
    resetAll: $("resetAll"), toast: $("toast")
  };

  /* ============================ timer ============================ */
  let endAt = 0;
  const EXT_NS = "purestudy";
  function extSend(type, extra) {
    try {
      if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.id) return;
      const pending = chrome.runtime.sendMessage(Object.assign({ type: EXT_NS + ":" + type }, extra || {}));
      if (pending && typeof pending.catch === "function") pending.catch(() => {});
    } catch (e) {}
  }
  function newSessionId() {
    try { return crypto.randomUUID(); } catch (e) { return String(Date.now()) + "-" + Math.random().toString(36).slice(2); }
  }
  let tick = null;
  let milestones = { half: false, last: false };
  let sleepTimer = null;

  const durationOf = mode =>
    mode === "work" ? S.settings.work : mode === "short" ? S.settings.short : S.settings.long;

  const MODE_LABEL = { work: "Focus", short: "Short break", long: "Long break" };

  function applyModeClass() {
    document.body.classList.toggle("mode-break", S.timer.mode === "short");
    document.body.classList.toggle("mode-long", S.timer.mode === "long");
    document.body.classList.toggle("running", S.timer.running);
  }

  function paint() {
    const total = durationOf(S.timer.mode) * 60;
    const rem = Math.max(0, Math.min(total, S.timer.remaining));
    const mm = Math.floor(rem / 60);
    const ss = rem % 60;
    el.time.textContent = `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
    el.modeLabel.textContent = MODE_LABEL[S.timer.mode];

    const frac = total > 0 ? 1 - rem / total : 0;
    el.ring.style.strokeDasharray = CIRC;
    el.ring.style.strokeDashoffset = CIRC * (1 - frac);

    if (S.timer.mode === "work") {
      const n = (S.timer.blocksDone % S.settings.blocks) + 1;
      el.sub.innerHTML = `Block <b>${n}</b> of ${S.settings.blocks}`;
    } else {
      el.sub.innerHTML = S.timer.mode === "long" ? "Long break · you earned it" : "Short break · stand up";
    }

    // cycle dots
    const dots = S.settings.blocks;
    const done = S.timer.blocksDone % S.settings.blocks;
    let html = "";
    for (let i = 0; i < dots; i++) {
      const cls = i < done ? "cycle done" : (i === done && S.timer.mode === "work" ? "cycle now" : "cycle");
      html += `<span class="${cls}"></span>`;
    }
    el.cycles.innerHTML = html;

    el.startBtn.textContent = S.timer.running ? "Pause" : (S.timer.remaining < durationOf(S.timer.mode) * 60 ? "Resume" : "Start");
    document.title = S.timer.running
      ? `${el.time.textContent} · ${MODE_LABEL[S.timer.mode]}`
      : "PureStudy — Study Timer";

    applyModeClass();
    paintStats();
    paintFocusTask();
    paintExam();
    paintCoach();
  }

  function run(existingEndAt, existingSessionId) {
    if (S.timer.running) return;
    S.timer.running = true;
    const now = Date.now();
    endAt = Number(existingEndAt) > now ? Number(existingEndAt) : now + Math.max(0, S.timer.remaining) * 1000;
    S.timer.endAt = endAt;
    S.timer.sessionId = existingSessionId || S.timer.sessionId || newSessionId();
    clearInterval(tick);
    tick = setInterval(loop, 200);
    document.body.classList.remove("sleepy");
    clearTimeout(sleepTimer);
    paint();
    save();
    extSend("timer-start", { endAt: S.timer.endAt, mode: S.timer.mode, sessionId: S.timer.sessionId });
  }

  function pause() {
    if (!S.timer.running) return;
    const cancelledSessionId = S.timer.sessionId || "";
    S.timer.remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
    S.timer.running = false;
    S.timer.endAt = 0;
    S.timer.sessionId = "";
    clearInterval(tick);
    tick = null;
    markActive();
    paint();
    save();
    extSend("timer-cancel", { reason: "pause", sessionId: cancelledSessionId });
  }

  function loop() {
    const rem = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
    if (rem !== S.timer.remaining) {
      S.timer.remaining = rem;
      paint();
    }

    // Your buddy checks in during the block
    if (S.timer.mode === "work" && S.timer.running) {
      const total = durationOf("work") * 60;
      if (!milestones.half && rem <= total * 0.5 && rem > 65) {
        milestones.half = true;
        buddySay("Halfway. Don't stop now.", 4500);
      }
      if (!milestones.last && rem <= 60 && rem > 0) {
        milestones.last = true;
        buddySay("One minute left. Finish strong.", 5000);
      }
    }

    if (rem <= 0) {
      clearInterval(tick);
      tick = null;
      S.timer.running = false;
      complete();
    }
  }

  function complete() {
    const finished = S.timer.mode;
    const finishedSessionId = S.timer.sessionId || "";
    S.timer.running = false;
    S.timer.endAt = 0;
    S.timer.sessionId = "";
    const mins = durationOf(finished);
    const linked = finished === "work" ? focusedTodo() : null;
    let msg = "";

    if (finished === "work") {
      const gained = award(mins);
      if (linked) linked.focusMinutes = (Number(linked.focusMinutes) || 0) + mins;
      S.stats.treats = (Number(S.stats.treats) || 0) + 1;
      S.timer.blocksDone += 1;
      const setDone = S.timer.blocksDone % S.settings.blocks === 0;
      const goal = Math.max(1, Number(S.settings.dailyGoal) || 3);
      const hitGoal = (S.stats.todaySessions || 0) >= goal;
      msg = `<span class="xp">+${gained.xp} XP</span> · ${mins} min logged · +1 treat${gained.bonus ? " · streak bonus +5" : ""}${setDone ? " · set complete" : ""}${hitGoal ? " · daily goal reached" : ""}${linked ? ` · ${mins} min on “${escapeHtml(shortTask(linked.text, 26))}”` : ""}`;

      // the biggest news wins the speech bubble
      if (gained.levelUp) {
        buddySay("Level up! We're getting stronger.", 7000);
        buddyHappy();
      } else if (gained.streakMilestone) {
        buddySay(`${S.stats.streak}-day streak. I'm impressed.`, 7000);
        buddyHappy();
      } else if (hitGoal) {
        buddySay("Daily goal done. I'm so proud of you.", 6500);
        buddyHappy();
      } else if (linked) {
        buddySay(`Block done. ${mins} minute${mins === 1 ? "" : "s"} closer on “${shortTask(linked.text, 28)}”.`, 6200);
      } else {
        buddySay(`Block done. ${S.stats.todaySessions}/${goal} today.`, 6000);
      }
      S.timer.mode = setDone ? "long" : "short";
    } else {
      msg = finished === "long" ? "Set complete. Start the next one." : "Break over. Back in.";
      buddySay(finished === "long" ? "Set complete. Go rest." : "Break. Stand up, human.", 4500);
      S.timer.mode = "work";
    }

    milestones = { half: false, last: false };
    S.timer.remaining = durationOf(S.timer.mode) * 60;
    paintTodos();
    paintFocusTask();
    paintCoach();
    beep(finished === "work");
    toast(msg);

    if (finishedSessionId) extSend("timer-complete", { sessionId: finishedSessionId, mode: finished });
    if (S.settings.auto) run();
    else paint();
    save();
  }

  function award(mins) {
    rollDay();
    const prevLevel = Math.floor(S.stats.xp / 100) + 1;
    const prevStreak = S.stats.streak;

    if (S.stats.lastDate === todayKey()) {
      // same day, streak unchanged
    } else if (S.stats.lastDate && daysBetween(S.stats.lastDate, todayKey()) === 1) {
      S.stats.streak += 1;
    } else {
      S.stats.streak = 1;
    }
    S.stats.lastDate = todayKey();
    S.stats.bestStreak = Math.max(S.stats.bestStreak || 0, S.stats.streak);

    const base = Math.max(1, Math.round(mins * 0.4));
    const bonus = S.stats.streak >= 3 ? 5 : 0;
    const xp = base + bonus;
    const levelUp = Math.floor((S.stats.xp + xp) / 100) + 1 > prevLevel;
    const streakMilestone = S.stats.streak !== prevStreak && [3, 7, 14, 30, 60, 100].includes(S.stats.streak);

    S.stats.xp += xp;
    S.stats.totalSessions += 1;
    S.stats.totalMinutes += mins;
    S.stats.todayMinutes += mins;
    S.stats.todayXp += xp;
    S.stats.todaySessions = (S.stats.todaySessions || 0) + 1;

    const k = todayKey();
    S.stats.week[k] = (S.stats.week[k] || 0) + mins;

    // keep the week map small
    const keys = Object.keys(S.stats.week).sort();
    while (keys.length > 60) delete S.stats.week[keys.shift()];

    return { xp, bonus, levelUp, streakMilestone };
  }

  function skip() {
    const cancelledSessionId = S.timer.sessionId || "";
    if (S.timer.running) {
      S.timer.remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      clearInterval(tick);
      tick = null;
      S.timer.running = false;
    }
    S.timer.endAt = 0;
    S.timer.sessionId = "";
    // skipping never awards XP
    if (S.timer.mode === "work") {
      S.timer.blocksDone += 1;
      const setDone = S.timer.blocksDone % S.settings.blocks === 0;
      S.timer.mode = setDone ? "long" : "short";
    } else {
      S.timer.mode = "work";
    }
    S.timer.remaining = durationOf(S.timer.mode) * 60;
    milestones = { half: false, last: false };
    paint();
    save();
    extSend("timer-cancel", { reason: "skip", sessionId: cancelledSessionId });
  }

  function resetTimer() {
    const cancelledSessionId = S.timer.sessionId || "";
    clearInterval(tick);
    tick = null;
    S.timer.running = false;
    S.timer.endAt = 0;
    S.timer.sessionId = "";
    S.timer.remaining = durationOf(S.timer.mode) * 60;
    milestones = { half: false, last: false };
    paint();
    save();
    extSend("timer-cancel", { reason: "reset", sessionId: cancelledSessionId });
  }

  /* ============================ audio ============================ */
  let audioCtx = null;
  function getCtx() {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === "suspended") audioCtx.resume();
    return audioCtx;
  }

  function beep(isWork, force) {
    if (!S.settings.sound && !force) return;
    try {
      const ctx = getCtx();
      const vol = Math.max(0, Math.min(100, Number(S.settings.volume) || 0)) / 100;
      if (vol <= 0 && !force) return;
      const peak = 0.5 * (force ? Math.max(vol, 0.6) : vol);
      if (peak <= 0) return;
      const style = S.settings.soundStyle || "chime";
      const t0 = ctx.currentTime + 0.02;

      const tone = (freq, at, dur, type, gain) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = type;
        o.frequency.value = freq;
        g.gain.setValueAtTime(0, at);
        g.gain.linearRampToValueAtTime(gain, at + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
        o.connect(g).connect(ctx.destination);
        o.start(at);
        o.stop(at + dur + 0.03);
      };

      if (style === "bell") {
        tone(1046.5, t0, 1.4, "sine", peak);
        tone(1568, t0 + 0.015, 1.1, "sine", peak * 0.6);
        tone(2093, t0 + 0.03, 0.7, "sine", peak * 0.25);
      } else if (style === "digital") {
        [0, 0.14, 0.28].forEach(d => tone(880, t0 + d, 0.1, "square", peak * 0.35));
      } else {
        const notes = isWork ? [659.25, 880, 1109.73] : [880, 659.25, 523.25];
        notes.forEach((f, i) => tone(f, t0 + i * 0.16, 0.32, "sine", peak));
      }
    } catch (e) {}
  }

  /* ============================ music ============================ */
  const Music = (() => {
    let master = null;
    let currentId = null;
    let stopFn = null;
    const noiseBufs = {};

    const actx = () => getCtx();

    function makeNoise(type) {
      const ctx = actx();
      if (noiseBufs[type]) return noiseBufs[type];
      const len = Math.floor(ctx.sampleRate * 4);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      let last = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        if (type === "brown") {
          last = (last + 0.02 * w) / 1.02;
          d[i] = last * 3.2;
        } else {
          d[i] = w * 0.55;
        }
      }
      noiseBufs[type] = buf;
      return buf;
    }

    function loopNoise(type, rate) {
      const src = actx().createBufferSource();
      src.buffer = makeNoise(type);
      src.loop = true;
      if (rate) src.playbackRate.value = rate;
      src.start();
      return src;
    }

    function filter(type, freq, q) {
      const f = actx().createBiquadFilter();
      f.type = type;
      f.frequency.value = freq;
      if (q) f.Q.value = q;
      return f;
    }

    function gnode(v) {
      const g = actx().createGain();
      g.gain.value = v;
      return g;
    }

    const vol01 = () => Math.max(0, Math.min(100, Number(S.settings.musicVolume) || 0)) / 100;

    function ensureMaster() {
      const ctx = actx();
      if (!master) {
        master = ctx.createGain();
        master.connect(ctx.destination);
      }
      master.gain.setTargetAtTime(vol01() * 0.55, ctx.currentTime, 0.05);
      return master;
    }

    function setVolume(v) {
      if (!master) return;
      const ctx = actx();
      master.gain.setTargetAtTime(Math.max(0, Math.min(1, v / 100)) * 0.55, ctx.currentTime, 0.04);
    }

    function stop() {
      if (!stopFn) return;
      const fn = stopFn;
      stopFn = null;
      currentId = null;
      fn();
    }

    function play(id) {
      const ctx = actx();
      stop();
      ensureMaster();

      const out = ctx.createGain();
      out.gain.value = 0;
      out.connect(master);
      out.gain.linearRampToValueAtTime(1, ctx.currentTime + 0.35);

      const timers = [];
      const nodes = [];
      const builders = { lofi: buildLofi, rain: buildRain, ocean: buildOcean, brown: buildBrown, pad: buildPad };
      (builders[id] || buildLofi)(out, timers, nodes);
      currentId = id;

      stopFn = () => {
        timers.forEach(t => clearInterval(t));
        setTimeout(() => nodes.forEach(n => { try { n.stop(); } catch (e) {} }), 220);
        try {
          out.gain.cancelScheduledValues(ctx.currentTime);
          out.gain.setValueAtTime(out.gain.value, ctx.currentTime);
          out.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.18);
        } catch (e) {}
        setTimeout(() => { try { out.disconnect(); } catch (e) {} }, 450);
      };
    }

    function buildRain(out, timers, nodes) {
      const ctx = actx();
      const src = loopNoise("white");
      src.connect(filter("highpass", 500, 0.6))
        .connect(filter("lowpass", 5200, 0.7))
        .connect(gnode(0.2))
        .connect(out);
      nodes.push(src);

      const drop = () => {
        const t = ctx.currentTime + Math.random() * 0.25;
        const o = ctx.createOscillator();
        o.type = "sine";
        o.frequency.value = 900 + Math.random() * 1600;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(0.02 + Math.random() * 0.02, t + 0.006);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
        o.connect(g).connect(out);
        o.start(t);
        o.stop(t + 0.12);
      };
      timers.push(setInterval(() => { if (Math.random() < 0.6) drop(); }, 380));
      drop();
      drop();
    }

    function buildOcean(out, timers, nodes) {
      const ctx = actx();
      const src = loopNoise("brown");
      const g = gnode(0.16);
      src.connect(filter("lowpass", 650, 0.5)).connect(g).connect(out);

      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.09;
      const depth = gnode(0.09);
      lfo.connect(depth);
      depth.connect(g.gain);
      lfo.start();
      nodes.push(src, lfo);
    }

    function buildBrown(out, timers, nodes) {
      const src = loopNoise("brown");
      src.connect(filter("lowpass", 420, 0.5)).connect(gnode(0.4)).connect(out);
      nodes.push(src);
    }

    function buildPad(out, timers, nodes) {
      const ctx = actx();
      const chords = [
        [220, 261.63, 329.63, 392],
        [174.61, 220, 261.63, 349.23],
        [261.63, 329.63, 392, 493.88],
        [196, 246.94, 293.66, 392]
      ];
      let idx = 0;
      let next = ctx.currentTime + 0.05;

      const chord = (freqs, t) => {
        freqs.forEach(f => {
          [0, 1].forEach(k => {
            const o = ctx.createOscillator();
            o.type = k ? "sine" : "triangle";
            o.frequency.value = f * (k ? 1.004 : 1);
            const g = ctx.createGain();
            g.gain.setValueAtTime(0, t);
            g.gain.linearRampToValueAtTime(0.03, t + 2.4);
            g.gain.linearRampToValueAtTime(0.0001, t + 8.8);
            o.connect(filter("lowpass", 720, 0.4)).connect(g).connect(out);
            o.start(t);
            o.stop(t + 9);
          });
        });
      };

      const sched = () => {
        while (next < ctx.currentTime + 1.2) {
          chord(chords[idx % chords.length], next);
          idx++;
          next += 7.5;
        }
      };
      sched();
      timers.push(setInterval(sched, 600));
    }

    function buildLofi(out, timers, nodes) {
      const ctx = actx();
      const stepDur = 60 / 74 / 2;
      const chords = [
        [261.63, 329.63, 392, 493.88],
        [220, 261.63, 329.63, 392],
        [174.61, 220, 261.63, 329.63],
        [196, 246.94, 293.66, 392]
      ];
      const bass = [65.41, 55, 43.65, 49];

      const vin = loopNoise("white", 0.55);
      vin.connect(filter("highpass", 1600, 0.5)).connect(gnode(0.05)).connect(out);
      nodes.push(vin);

      const pop = () => {
        const t = ctx.currentTime + Math.random() * 0.2;
        const src = ctx.createBufferSource();
        src.buffer = makeNoise("white");
        src.start(t, Math.random() * 3);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.02, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
        src.connect(filter("highpass", 2500, 0.6)).connect(g).connect(out);
        src.stop(t + 0.05);
      };
      timers.push(setInterval(() => { if (Math.random() < 0.55) pop(); }, 650));

      const rhodes = (f, t, dur, vol) => {
        const o1 = ctx.createOscillator();
        o1.type = "sine";
        o1.frequency.value = f;
        const o2 = ctx.createOscillator();
        o2.type = "triangle";
        o2.frequency.value = f * 2;
        const o2g = ctx.createGain();
        o2g.gain.value = 0.16;
        const mix = ctx.createGain();
        o1.connect(mix);
        o2.connect(o2g).connect(mix);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(vol, t + 0.012);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        mix.connect(filter("lowpass", 1500, 0.5)).connect(g).connect(out);
        o1.start(t);
        o2.start(t);
        o1.stop(t + dur + 0.05);
        o2.stop(t + dur + 0.05);
      };

      const kick = t => {
        const o = ctx.createOscillator();
        o.type = "sine";
        o.frequency.setValueAtTime(110, t);
        o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.35, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
        o.connect(g).connect(out);
        o.start(t);
        o.stop(t + 0.32);
      };

      const snare = t => {
        const src = ctx.createBufferSource();
        src.buffer = makeNoise("white");
        src.start(t, Math.random() * 3);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.1, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.15);
        src.connect(filter("bandpass", 1900, 0.9)).connect(g).connect(out);
        src.stop(t + 0.17);
      };

      const hat = (t, v) => {
        const src = ctx.createBufferSource();
        src.buffer = makeNoise("white");
        src.start(t, Math.random() * 3);
        const g = ctx.createGain();
        g.gain.setValueAtTime(v, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
        src.connect(filter("highpass", 7000, 0.7)).connect(g).connect(out);
        src.stop(t + 0.07);
      };

      let step = 0;
      let bar = 0;
      let next = ctx.currentTime + 0.1;

      const playStep = (s, t) => {
        if (s === 0) {
          chords[bar % 4].forEach(f => rhodes(f, t, 3.2, 0.035));
          rhodes(bass[bar % 4], t, 2.2, 0.09);
        }
        if (s === 0 || s === 4) kick(t);
        if (s === 2 || s === 6) snare(t);
        hat(t, s % 2 === 0 ? 0.035 : 0.018);
      };

      const sched = () => {
        while (next < ctx.currentTime + 0.5) {
          playStep(step, next);
          next += stepDur;
          step++;
          if (step >= 8) { step = 0; bar++; }
        }
      };
      sched();
      timers.push(setInterval(sched, 120));
    }

    return { play, stop, setVolume, current: () => currentId };
  })();

  const TRACK_NAMES = { lofi: "Lo-fi", rain: "Rain", ocean: "Ocean", brown: "Brown noise", pad: "Deep focus" };
  let uiTrack = null;
  function paintMusic(id) {
    uiTrack = id;
    document.querySelectorAll(".track").forEach(b => b.classList.toggle("playing", b.dataset.track === id));
    el.musicNow.textContent = id ? `Playing · ${TRACK_NAMES[id]}` : "Nothing playing";
    el.musicDot.classList.toggle("on", !!id);
  }
  function toggleTrack(id) {
    if (uiTrack === id) {
      Music.stop();
      paintMusic(null);
      return;
    }
    try {
      Music.play(id);
      paintMusic(id);
    } catch (e) {
      toast("Couldn't start audio on this device.");
    }
  }

  /* ============================ toast ============================ */
  let toastTimer = null;
  function toast(html) {
    el.toast.innerHTML = html;
    el.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.remove("show"), 3600);
  }

  /* ============================ stats paint ============================ */
  function paintStats() {
    rollDay();
    const level = Math.floor(S.stats.xp / 100) + 1;
    const into = S.stats.xp % 100;

    el.lvlPill.textContent = level;
    el.lvlNum.textContent = level;
    el.xpText.textContent = `${S.stats.xp} XP · ${into} / 100 to next`;
    el.xpBar.style.width = into + "%";
    el.streakPill.textContent = S.stats.streak;

    el.todayMin.textContent = S.stats.todayMinutes;
    el.todayXp.textContent = S.stats.todayXp;

    el.sStreak.textContent = S.stats.streak;
    el.sBest.textContent = S.stats.bestStreak;
    el.sSessions.textContent = S.stats.totalSessions;
    el.sMinutes.textContent = S.stats.totalMinutes;

    paintWeek();
    paintGoal();
    paintBuddy();
    paintGreeting();
  }

  function paintGoal() {
    const done = S.stats.todaySessions || 0;
    const goal = Math.max(1, Number(S.settings.dailyGoal) || 3);
    const pct = Math.min(100, Math.round((done / goal) * 100));
    const hit = done >= goal;
    const left = Math.max(0, goal - done);
    const shown = Math.min(done, goal);

    const line = hit
      ? (S.stats.streak >= 3 ? `${S.stats.streak}-day streak. Goal complete.` : "Daily goal complete. Anything else is a bonus.")
      : done === 0
        ? "One block starts the day. You've got this."
        : left === 1
          ? "One block left. Finish the day strong."
          : `${left} blocks left. Keep the chain going.`;
    el.goalText.textContent = line;
    el.goalCount.textContent = `${shown}/${goal}`;
    el.goalBar.style.width = pct + "%";
    el.goalFrac.textContent = `${done} / ${goal} blocks`;
    el.goalBar2.style.width = pct + "%";
    el.goalHint.textContent = hit
      ? "Done for today. Anything more is a bonus."
      : `Finish ${left} more block${left === 1 ? "" : "s"} to hit today's goal.`;
    if (el.momentum) {
      el.momentum.classList.toggle("hit", hit);
      el.momentum.setAttribute("aria-valuemax", String(goal));
      el.momentum.setAttribute("aria-valuenow", String(shown));
      el.momentum.setAttribute("aria-valuetext", `${shown} of ${goal} blocks done`);
    }
  }

  const BUDDY_LINES = {
    idle: ["Ready when you are. One block?", "I'm not going anywhere. Sit down.", "Phone in the other room?", "Start small. 25 minutes."],
    work: ["We're doing it.", "I'm reading with you.", "Don't look at your phone.", "25 minutes. Easy.", "Just this one block."],
    short: ["Stand up, human.", "Water. Now.", "Break means break.", "Look out a window for a second."],
    long: ["Set complete. I'm proud of you.", "That's three. Go rest.", "You earned this break."],
    done: ["Daily goal done. Look at you.", "You showed up. That's the whole trick.", "Proud of you. Seriously."],
    pet: ["Happy sounds.", "That's the spot.", "Okay. Now one block?", "I like you. Let's study."],
    feed: ["Nom. Thank you.", "Best treat. Now one block?", "Treat first, focus after.", "I'd study another block for one of these."]
  };

  let buddyHoldTimer = null;
  const pickLine = arr => arr[Math.floor(Math.random() * arr.length)];

  const GREET_LINES = [
    "Small block. Real progress.",
    "One page at a time.",
    "Start ugly. Fix it later.",
    "You don't have to feel ready.",
    "A little focus goes a long way.",
    "__PET__ is already waiting.",
    "Make this one count.",
    "Future you says thanks."
  ];

  function greetingLine() {
    if (S.timer.running) return "You're in it. Keep going.";
    if (S.timer.mode !== "work") return "Break earned. Recharge.";
    const goal = Math.max(1, Number(S.settings.dailyGoal) || 3);
    if ((S.stats.todaySessions || 0) >= goal) return "Goal hit. Take the win.";
    if (S.stats.streak >= 3) return `${S.stats.streak}-day streak. Keep it alive.`;
    const seed = Array.from(todayKey() + cleanName(S.settings.name)).reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
    const line = GREET_LINES[seed % GREET_LINES.length];
    return line.replace("__PET__", petName());
  }

  function paintGreeting() {
    if (!el.greeting) return;
    const name = cleanName(S.settings.name);
    el.greeting.hidden = !name;
    if (!name) return;
    const nextName = `Hi, ${name}.`;
    const nextLine = greetingLine();
    if (el.greetName.textContent !== nextName) el.greetName.textContent = nextName;
    if (el.greetLine.textContent !== nextLine) el.greetLine.textContent = nextLine;
  }

  function defaultBuddy() {
    const goal = Math.max(1, Number(S.settings.dailyGoal) || 3);
    if (S.timer.mode !== "work") return pickLine(S.timer.mode === "long" ? BUDDY_LINES.long : BUDDY_LINES.short);
    if (S.timer.running) return pickLine(BUDDY_LINES.work);
    if (S.stats.streak >= 3 && Math.random() < 0.45) return `${S.stats.streak}-day streak. Don't break it.`;
    if ((S.stats.todaySessions || 0) >= goal) return pickLine(BUDDY_LINES.done);
    const line = pickLine(BUDDY_LINES.idle);
    const name = cleanName(S.settings.name);
    return name && Math.random() < 0.28 ? `Hi ${name}. ${line}` : line;
  }

  function buddySay(text, hold) {
    if (!el.buddyLine) return;
    el.buddyLine.textContent = text;
    clearTimeout(buddyHoldTimer);
    if (hold !== 0) {
      buddyHoldTimer = setTimeout(() => {
        buddyHoldTimer = null;
        el.buddyLine.textContent = defaultBuddy();
      }, hold || 5200);
    }
  }

  function buddyHappy() {
    document.body.classList.add("buddy-happy");
    spawnHearts();
    setTimeout(spawnHearts, 260);
    setTimeout(() => document.body.classList.remove("buddy-happy"), 1600);
  }

  function feedPet() {
    const treats = Math.max(0, Number(S.stats.treats) || 0);
    if (treats < 1) {
      buddySay("Finish a focus block first. Then we eat.", 4300);
      toast("No treats yet — finish a focus block to earn one.");
      return;
    }
    const treat = treatFor();
    S.stats.treats = treats - 1;
    S.stats.fed = (Number(S.stats.fed) || 0) + 1;
    el.petBtn.classList.remove("feeding");
    void el.petBtn.offsetWidth;
    el.petBtn.classList.add("feeding");
    setTimeout(() => el.petBtn.classList.remove("feeding"), 1300);
    spawnHearts(treat.icon, 2);
    buddySay(pickLine(BUDDY_LINES.feed), 3800);
    paintBuddy();
    save();
    markActive();
    toast(`${escapeHtml(petName())} loved the ${treat.one}.`);
  }

  function paintBuddy() {
    const bond = S.stats.totalSessions || 0;
    const treats = Math.max(0, Number(S.stats.treats) || 0);
    const treat = treatFor();
    el.bondText.textContent = "♥ " + bond;
    el.bondText.title = `${bond} blocks studied together`;
    if (el.treatText) {
      el.treatText.textContent = `${treat.icon} ${treats} ${treats === 1 ? "treat" : "treats"}`;
      el.treatText.title = `${treats} ${treats === 1 ? treat.one : treat.many} earned from focus blocks`;
    }
    document.body.classList.toggle("has-scarf", bond >= 10);
    document.body.classList.toggle("has-glasses", bond >= 25);
    document.body.classList.toggle("has-cap", bond >= 50);
    if (el.buddyCard) el.buddyCard.style.display = S.settings.buddy ? "" : "none";
    paintPet();
  }

  function spawnHearts(symbol = "♥", count = 3) {
    for (let i = 0; i < count; i++) {
      const h = document.createElement("span");
      h.textContent = symbol;
      if (symbol !== "♥") h.style.fontSize = "15px";
      h.style.left = (18 + Math.random() * 44) + "%";
      h.style.animationDelay = (i * 90) + "ms";
      el.petHearts.appendChild(h);
      setTimeout(() => h.remove(), 1600 + i * 90);
    }
  }

  // Your buddy naps if the app sits idle for a minute
  function markActive() {
    document.body.classList.remove("sleepy");
    clearTimeout(sleepTimer);
    sleepTimer = setTimeout(() => {
      if (!S.timer.running) document.body.classList.add("sleepy");
    }, 60000);
  }

  function paintWeek() {
    const days = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      days.push({ key: todayKey(d), label: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"][d.getDay()] });
    }
    const max = Math.max(25, ...days.map(d => S.stats.week[d.key] || 0));
    const any = days.some(d => (S.stats.week[d.key] || 0) > 0);
    el.weekChart.innerHTML = days.map(d => {
      const v = S.stats.week[d.key] || 0;
      const h = v > 0 ? Math.max(10, Math.round((v / max) * 96)) : 4;
      const bg = v > 0 ? "var(--accent)" : "#243444";
      return `<div title="${v} min" style="height:${h}px;background:${bg};border-radius:6px;opacity:${v > 0 ? 0.9 : 0.7}"></div>`;
    }).join("");
    el.weekLabels.innerHTML = days.map(d =>
      `<div style="${d.key === todayKey() ? "color:var(--accent);font-weight:700" : ""}">${d.label}</div>`
    ).join("");
    const empty = $("weekEmpty");
    if (empty) empty.style.display = any ? "none" : "block";
  }

  /* ============================ journal ============================ */
  function paintJournal() {
    if (!S.journal.length) {
      el.journalList.innerHTML = `<div class="empty">No mistakes logged yet.<br>Wrong answers are the best study material you have.</div>`;
      return;
    }
    el.journalList.innerHTML = S.journal.map(e => `
      <div class="entry">
        <div class="txt">${escapeHtml(e.text)}<div class="date">${e.date}</div></div>
        <button class="del" data-id="${e.id}" title="Delete">×</button>
      </div>`).join("");
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  /* ============================ to-do list ============================ */
  function focusedTodo() {
    return S.todos.find(t => t.id === S.focusTask && !t.done) || null;
  }

  function paintFocusTask() {
    if (!el.focusTask) return;
    const todo = focusedTodo();
    if (!todo) {
      el.focusTask.hidden = true;
      return;
    }
    el.focusTask.hidden = false;
    const label = shortTask(todo.text, 52);
    if (el.focusTaskName.textContent !== label) el.focusTaskName.textContent = label;
    el.focusTask.title = todo.text;
  }

  function toggleFocusTask(id) {
    const todo = S.todos.find(t => t.id === id && !t.done);
    if (!todo) return;
    S.focusTask = S.focusTask === id ? null : id;
    save();
    paintTodos();
    paintFocusTask();
    paintCoach();
    if (S.focusTask) {
      buddySay(`“${shortTask(todo.text, 36)}” is our next block.`, 4600);
      toast(`Timer linked to “${escapeHtml(shortTask(todo.text, 42))}”.`);
    } else {
      toast("Task unlinked. The timer still works.");
    }
  }

  function cycleTodoPriority(todo) {
    if (!todo || todo.done) return;
    todo.priority = NEXT_PRIORITY[todo.priority] || "high";
    save();
    paintTodos();
    paintCoach();
    toast(`${TODO_PRIORITIES[todo.priority].label} priority · ${escapeHtml(shortTask(todo.text, 42))}`);
  }

  function spawnConfetti() {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const layer = document.createElement("div");
    layer.className = "confetti-layer";
    layer.setAttribute("aria-hidden", "true");
    const colors = ["var(--accent)", "#fbbf24", "#f472b6", "#60a5fa", "#a78bfa"];
    for (let i = 0; i < 28; i++) {
      const bit = document.createElement("i");
      bit.className = "confetti-bit";
      bit.style.left = (4 + Math.random() * 92) + "%";
      bit.style.background = colors[i % colors.length];
      bit.style.animationDelay = Math.round(Math.random() * 220) + "ms";
      bit.style.animationDuration = (1.35 + Math.random() * 0.7) + "s";
      bit.style.width = (5 + Math.random() * 4) + "px";
      bit.style.height = (7 + Math.random() * 6) + "px";
      bit.style.setProperty("--drift", Math.round(-55 + Math.random() * 110) + "px");
      layer.appendChild(bit);
    }
    document.body.appendChild(layer);
    setTimeout(() => layer.remove(), 2400);
  }

  function celebrateTodo(todo) {
    const left = S.todos.filter(t => !t.done).length;
    spawnConfetti();
    buddyHappy();
    spawnHearts("✨", 2);
    buddySay(left
      ? `${petName()} is proud of you. One less thing.`
      : `Every task done. ${petName()} is doing a little happy hop.`, 4600);
    toast(left
      ? `Task complete · ${escapeHtml(shortTask(todo.text, 44))}`
      : `All tasks done · ${escapeHtml(shortTask(todo.text, 34))}`);
  }

  function paintTodoMeta() {
    const total = S.todos.length;
    const done = S.todos.filter(t => t.done).length;
    if (el.todoCount) {
      el.todoCount.textContent = !total ? "no tasks" : done === total ? "all done" : `${done}/${total} done`;
      el.todoCount.style.color = total && done === total ? "var(--accent)" : "";
    }
    if (el.todoClear) el.todoClear.hidden = done === 0;
    if (el.todoEmpty) el.todoEmpty.hidden = total > 0;
    if (el.todoList) el.todoList.hidden = total === 0;
  }

  function paintTodos() {
    if (!el.todoList) return;
    el.todoList.innerHTML = "";
    for (const todo of S.todos) {
      const isFocused = S.focusTask === todo.id && !todo.done;
      const row = document.createElement("div");
      row.className = "todo-item" + (todo.done ? " done" : "") + (isFocused ? " focused" : "");
      row.dataset.id = todo.id;

      const priority = document.createElement("button");
      priority.type = "button";
      priority.className = "todo-priority " + (TODO_PRIORITIES[todo.priority] ? todo.priority : "normal");
      priority.disabled = todo.done;
      priority.title = `Priority: ${TODO_PRIORITIES[todo.priority]?.label || "Normal"} · click to change`;
      priority.setAttribute("aria-label", `Priority: ${TODO_PRIORITIES[todo.priority]?.label || "Normal"}. Change priority for ${todo.text}`);
      priority.addEventListener("click", () => cycleTodoPriority(todo));

      const main = document.createElement("label");
      main.className = "todo-main";
      const check = document.createElement("input");
      check.type = "checkbox";
      check.className = "todo-check";
      check.checked = todo.done;
      check.addEventListener("change", () => {
        const completed = check.checked;
        todo.done = completed;
        if (completed && S.focusTask === todo.id) S.focusTask = null;
        save();
        paintTodos();
        paintFocusTask();
        paintCoach();
        if (completed) celebrateTodo(todo);
      });

      const copy = document.createElement("span");
      copy.className = "todo-copy";
      const text = document.createElement("span");
      text.className = "todo-text";
      text.textContent = todo.text;
      text.title = todo.text;
      copy.appendChild(text);
      if (todo.focusMinutes > 0) {
        const time = document.createElement("span");
        time.className = "todo-time";
        time.textContent = `${todo.focusMinutes} min focused`;
        copy.appendChild(time);
      }
      main.append(check, copy);

      const focus = document.createElement("button");
      focus.type = "button";
      focus.className = "todo-focus" + (isFocused ? " focused" : "");
      focus.textContent = isFocused ? "◉" : "◎";
      focus.disabled = todo.done;
      focus.title = isFocused ? `Unlink timer from ${todo.text}` : `Link timer to ${todo.text}`;
      focus.setAttribute("aria-label", isFocused ? `Stop focusing on ${todo.text}` : `Focus on ${todo.text}`);
      focus.addEventListener("click", () => toggleFocusTask(todo.id));

      const del = document.createElement("button");
      del.type = "button";
      del.className = "todo-del";
      del.textContent = "×";
      del.setAttribute("aria-label", `Delete task: ${todo.text}`);
      del.addEventListener("click", () => {
        S.todos = S.todos.filter(t => t.id !== todo.id);
        if (S.focusTask === todo.id) S.focusTask = null;
        save();
        paintTodos();
        paintFocusTask();
        paintCoach();
        el.todoInput.focus();
      });

      row.append(priority, main, focus, del);
      el.todoList.appendChild(row);
    }
    paintTodoMeta();
  }

  function addTodo() {
    const text = cleanTodo(el.todoInput.value);
    if (!text) {
      el.todoInput.focus();
      return;
    }
    if (S.todos.length >= 30) {
      toast("That's a full list. Finish one or clear some space.");
      el.todoInput.focus();
      return;
    }
    S.todos.push({ id: newTodoId(), text, done: false, priority: "normal", focusMinutes: 0 });
    el.todoInput.value = "";
    save();
    paintTodos();
    paintCoach();
    el.todoInput.focus();
  }

  function clearDoneTodos() {
    if (!S.todos.some(t => t.done)) return;
    S.todos = S.todos.filter(t => !t.done);
    if (!S.todos.some(t => t.id === S.focusTask && !t.done)) S.focusTask = null;
    save();
    paintTodos();
    paintFocusTask();
    paintCoach();
    toast("Cleared completed tasks.");
    el.todoInput.focus();
  }

  /* ============================ study coach ============================ */
  let coachVariant = 0;

  function coachPick(arr) {
    return arr[coachVariant % arr.length];
  }

  function coachAdvice() {
    const open = S.todos.filter(t => !t.done);
    const linked = focusedTodo();
    const exam = examDetails();
    const goal = Math.max(1, Number(S.settings.dailyGoal) || 3);
    const done = S.stats.todaySessions || 0;
    const left = Math.max(0, goal - done);
    const pet = petName();
    const name = cleanName(S.settings.name);

    if (!open.length) {
      if (exam && exam.days >= 0 && exam.days <= 7) {
        return coachPick([
          `${exam.name} is close. Add one tiny review task, not a giant plan.`,
          `No tasks yet and ${exam.days === 0 ? "the exam is today" : `only ${exam.days} day${exam.days === 1 ? "" : "s"} left`}. Write down the first question you'd test yourself on.`,
          `Keep it small: one topic, one recall question, one block. ${pet} is ready.`
        ]);
      }
      return coachPick([
        "Your list is clear. Add one small next step — something you could finish in ten minutes.",
        "Nothing on the list yet. Write the first action, not the whole project.",
        "A blank list is a fresh start. What's one thing future you would thank you for?",
        `${name ? name + ", " : ""}start smaller than feels impressive. One tiny task is enough.`
      ]);
    }

    if (linked) {
      const task = shortTask(linked.text, 42);
      return coachPick([
        `You're set up for “${task}”. One block, then decide the next move.`,
        `Stay with “${task}” for this block. ${pet} is reading beside you.`,
        `Don't plan the whole week. Give “${task}” the next block and let that be enough.`
      ]);
    }

    if (exam && exam.days >= 0 && exam.days <= 7) {
      if (exam.days === 0) {
        return coachPick([
          "Exam today. One calm review block, then close the notes. Trust what you've built.",
          "No cramming marathons today. One focused recall pass, then breathe.",
          `${pet} says: you've prepared. Do the next calm thing, not everything at once.`
        ]);
      }
      return coachPick([
        `${exam.name} is in ${exam.days} day${exam.days === 1 ? "" : "s"}. Active recall beats rereading: close the notes and explain it out loud.`,
        `${exam.name} is coming. Pick one weak spot and give it a short, honest review block.`,
        `With ${exam.days} day${exam.days === 1 ? "" : "s"} left, depth beats volume. One topic, one block, one small win.`
      ]);
    }

    const high = open.find(t => t.priority === "high");
    if (high) {
      const task = shortTask(high.text, 42);
      return coachPick([
        `“${task}” is high priority. Start there for one block, then reassess.`,
        `The important thing is “${task}”. Give it ten honest minutes before anything else.`,
        `You marked “${task}” as high priority. Future you would start now.`
      ]);
    }

    if (done >= goal) {
      return coachPick([
        "Goal complete. Stop while it still feels good — rest is part of the method.",
        "You've done enough for today. Anything extra is a bonus, not a debt.",
        `${pet} is proud. Close the laptop on a win.`
      ]);
    }

    if (done === 0) {
      return coachPick([
        "The first block is the hardest. Start with ten minutes; momentum can meet you there.",
        "Don't wait to feel ready. Open one task and begin badly.",
        `${pet} is already waiting. One small block is a real start.`
      ]);
    }

    if (left === 1) {
      return coachPick([
        "One block left for today's goal. Make it small and specific.",
        "You're one block away. Protect the next few minutes and finish the chain.",
        `${pet} says one more, then we celebrate.`
      ]);
    }

    if (S.stats.streak >= 3) {
      return coachPick([
        `Your ${S.stats.streak}-day streak is a promise to yourself. One block keeps it alive.`,
        `${S.stats.streak} days in a row. Don't break the chain — just begin.`,
        `The streak is nice, but showing up today is the real win.`
      ]);
    }

    return coachPick([
      "Small steps, your pace. Open one task and begin.",
      "You don't need a perfect plan. You need the next ten minutes.",
      `${pet} believes in you. Pick the smallest useful thing.`
    ]);
  }

  function paintCoach() {
    if (el.coachText) {
      const next = coachAdvice();
      if (el.coachText.textContent !== next) el.coachText.textContent = next;
    }
    if (el.coachPick) {
      const hasTasks = S.todos.some(t => !t.done);
      const label = hasTasks ? "◎ Pick my next task" : "Add a task to begin";
      if (el.coachPick.textContent !== label) el.coachPick.textContent = label;
      if (el.coachPick.disabled !== !hasTasks) el.coachPick.disabled = !hasTasks;
    }
  }

  function pickCoachTask() {
    const open = S.todos.filter(t => !t.done);
    if (!open.length) {
      toast("Add a small task first. Then I'll pick one.");
      if (el.todoInput) el.todoInput.focus();
      return;
    }
    const rank = { high: 0, normal: 1, low: 2 };
    const notLinked = open.filter(t => t.id !== S.focusTask);
    const candidates = notLinked.length ? notLinked : open;
    const chosen = candidates.slice().sort((a, b) => (rank[a.priority] ?? 1) - (rank[b.priority] ?? 1))[0];
    if (!chosen) return;
    S.focusTask = chosen.id;
    coachVariant = 0;
    save();
    paintTodos();
    paintFocusTask();
    paintCoach();
    buddySay(`Let's start with “${shortTask(chosen.text, 36)}”.`, 5200);
    toast(`Focus set · ${escapeHtml(shortTask(chosen.text, 48))}`);
  }

  /* ============================ exam countdown ============================ */
  function paintExam() {
    const info = examDetails();
    if (el.examBadge) {
      if (!info) {
        el.examBadge.hidden = true;
        el.examBadge.classList.remove("soon", "past");
      } else {
        el.examBadge.hidden = false;
        const days = info.days;
        const text = days < 0
          ? `${info.name} · passed`
          : days === 0
            ? `${info.name} · today`
            : `${info.name} · ${days} day${days === 1 ? "" : "s"} left`;
        if (el.examBadgeText.textContent !== text) el.examBadgeText.textContent = text;
        el.examBadge.classList.toggle("soon", days >= 0 && days <= 7);
        el.examBadge.classList.toggle("past", days < 0);
        el.examBadge.title = days < 0
          ? `${info.name} has passed. Set a new date in Settings.`
          : `${info.name} · ${info.date}`;
      }
    }
    if (el.petSign) {
      if (!info || info.days < 0) {
        el.petSign.hidden = true;
      } else {
        el.petSign.hidden = false;
        const todayIsExam = info.days === 0;
        el.petSign.classList.toggle("today", todayIsExam);
        el.petSignDays.textContent = todayIsExam ? "today" : String(info.days);
        el.petSignLabel.textContent = todayIsExam ? "" : (info.days === 1 ? "day" : "days");
        el.petSign.title = `${info.name} · ${todayIsExam ? "today" : info.days + " days left"}`;
      }
    }
  }

  /* ============================ backup ============================ */
  function exportBackup() {
    const payload = {
      app: "PureStudy",
      version: APP_VERSION,
      exportedAt: new Date().toISOString(),
      state: S
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `purestudy-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast("Backup exported. Keep it somewhere safe.");
  }

  async function importBackupFile(ev) {
    const input = ev.target;
    const file = input.files && input.files[0];
    input.value = "";
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast("That backup is too large.");
      return;
    }
    let parsed;
    try {
      parsed = JSON.parse(await file.text());
    } catch (e) {
      toast("That file isn't valid JSON.");
      return;
    }
    const state = parsed && parsed.state && typeof parsed.state === "object" ? parsed.state : parsed;
    if (!state || typeof state !== "object" || Array.isArray(state)) {
      toast("That doesn't look like a PureStudy backup.");
      return;
    }
    const knownKeys = ["settings", "stats", "todos", "task", "journal", "mindmap", "timer", "focusTask"];
    const looksLikeState = knownKeys.some(k => Object.prototype.hasOwnProperty.call(state, k))
      && (state.settings === undefined || (typeof state.settings === "object" && !Array.isArray(state.settings)))
      && (state.stats === undefined || (typeof state.stats === "object" && !Array.isArray(state.stats)))
      && (state.todos === undefined || Array.isArray(state.todos))
      && (state.journal === undefined || Array.isArray(state.journal))
      && (state.mindmap === undefined || (typeof state.mindmap === "object" && !Array.isArray(state.mindmap)))
      && (state.timer === undefined || (typeof state.timer === "object" && !Array.isArray(state.timer)));
    if (!looksLikeState) {
      toast("That doesn't look like a PureStudy backup.");
      return;
    }
    if (!confirm("Import this backup? It will replace your current tasks, stats, journal, mind map and settings on this device.")) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(deepMerge(defaults(), state)));
      skipUnloadSave = true;
      location.reload();
    } catch (e) {
      skipUnloadSave = false;
      toast("Couldn't save the backup. Your current data is unchanged.");
    }
  }

  /* ============================ settings ============================ */
  function paintSettings() {
    el.setWork.value = S.settings.work;
    el.setShort.value = S.settings.short;
    el.setLong.value = S.settings.long;
    el.setBlocks.value = S.settings.blocks;
    el.setGoal.value = S.settings.dailyGoal;
    el.setAuto.checked = !!S.settings.auto;
    el.setSound.checked = !!S.settings.sound;
    el.setSoundStyle.value = S.settings.soundStyle;
    el.setVolume.value = S.settings.volume;
    el.volText.textContent = S.settings.volume + "%";
    el.setBuddy.checked = !!S.settings.buddy;
    if (el.setExamName) el.setExamName.value = S.settings.examName || "";
    if (el.setExamDate) el.setExamDate.value = S.settings.examDate || "";
    el.musicVol.value = S.settings.musicVolume;
    el.musicVolText.textContent = S.settings.musicVolume + "%";
  }

  function numField(node, key, min, max) {
    node.addEventListener("change", () => {
      let v = Math.round(Number(node.value));
      if (!Number.isFinite(v)) v = min;
      v = Math.max(min, Math.min(max, v));
      node.value = v;

      const before = durationOf(S.timer.mode) * 60;
      S.settings[key] = v;
      const after = durationOf(S.timer.mode) * 60;

      if (!S.timer.running) {
        // an untouched, full timer should resize to the new duration
        S.timer.remaining = S.timer.remaining >= before
          ? after
          : Math.min(S.timer.remaining, after);
        if (S.timer.remaining <= 0) S.timer.remaining = after;
      }
      paint();
      save();
    });
  }

  /* ============================ appearance ============================ */
  const ACCENTS = {
    mint: "#4ade80", blurple: "#5865f2", sky: "#38bdf8",
    sunset: "#fb923c", rose: "#f472b6", violet: "#a78bfa"
  };
  const LOGO_TONES = {
    mint:    { a: "#4ade80", a2: "#22c55e", ear: "#f7a8b8", hand: "#f6d3a0", g1: "#16242f", g2: "#080d13", edge: "#4ade80" },
    blurple: { a: "#818cf8", a2: "#5865f2", ear: "#eb459e", hand: "#f2f3f5", g1: "#1c1d33", g2: "#0c0d14", edge: "#818cf8" },
    sky:     { a: "#38bdf8", a2: "#0ea5e9", ear: "#f7a8b8", hand: "#e0f2fe", g1: "#0d2231", g2: "#071018", edge: "#38bdf8" },
    sunset:  { a: "#fb923c", a2: "#f97316", ear: "#f43f5e", hand: "#ffe4c7", g1: "#28150e", g2: "#120906", edge: "#fb923c" },
    rose:    { a: "#f472b6", a2: "#db2777", ear: "#c084fc", hand: "#ffe4f0", g1: "#28121e", g2: "#13070f", edge: "#f472b6" },
    violet:  { a: "#a78bfa", a2: "#7c3aed", ear: "#f0abfc", hand: "#f5f3ff", g1: "#1e1533", g2: "#0d0819", edge: "#a78bfa" },
    mono:    { a: "#cbd5e1", a2: "#94a3b8", ear: "#94a3b8", hand: "#f8fafc", g1: "#1d242d", g2: "#090c10", edge: "#cbd5e1" }
  };
  const LOGO_VARIANTS = [
    { id: "clock-mint",    shape: "clock", tone: "mint",    shapeName: "Clock cat",  toneName: "Mint" },
    { id: "clock-blurple", shape: "clock", tone: "blurple", shapeName: "Clock cat",  toneName: "Blurple" },
    { id: "face-sky",      shape: "face",  tone: "sky",     shapeName: "Cat face",   toneName: "Sky" },
    { id: "face-sunset",   shape: "face",  tone: "sunset",  shapeName: "Cat face",   toneName: "Sunset" },
    { id: "paw-mint",      shape: "paw",   tone: "mint",    shapeName: "Paw clock",  toneName: "Mint" },
    { id: "paw-violet",    shape: "paw",   tone: "violet",  shapeName: "Paw clock",  toneName: "Violet" },
    { id: "sleep-rose",    shape: "sleep", tone: "rose",    shapeName: "Sleepy cat", toneName: "Rose" },
    { id: "sleep-mono",    shape: "sleep", tone: "mono",    shapeName: "Sleepy cat", toneName: "Mono" }
  ];
  function petVariant(id) {
    return PET_VARIANTS.find(p => p.id === id) || PET_VARIANTS[0];
  }

  function petName(id = S.settings.pet) {
    const p = petVariant(id);
    const names = S.settings.petNames || {};
    return cleanName(names[p.id]) || p.name;
  }

  function treatFor(id = S.settings.pet) {
    return TREAT_TYPES[petVariant(id).treat] || TREAT_TYPES.fish;
  }

  function examDetails() {
    const raw = validExamDate(S.settings.examDate);
    if (!raw) return null;
    const [y, m, d] = raw.split("-").map(Number);
    const target = new Date(y, m - 1, d);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return {
      name: cleanExam(S.settings.examName) || "Exam",
      date: raw,
      days: Math.round((target - today) / 86400000)
    };
  }

  function shortTask(text, max = 44) {
    const chars = Array.from(cleanTodo(text));
    return chars.length > max ? chars.slice(0, max - 1).join("") + "…" : chars.join("");
  }

  function petSVG(id, mini = false) {
    const p = petVariant(id);
    const ink = "#20303f";
    const patch = p.patch || p.shade;
    const whisker = p.id === "glbani" ? "#a7abb0" : p.shade;
    let tail = "";
    if (p.tail === "cat") {
      tail = `<path class="tail" d="M59 63 C71 65 75 53 69 46" fill="none" stroke="${patch}" stroke-width="6" stroke-linecap="round"/>`;
      if (p.id === "glbani") tail += `<circle cx="69" cy="46" r="3.1" fill="${p.belly}"/>`;
    } else if (p.tail === "fox") {
      tail = `<path class="tail" d="M58 64 C73 70 82 58 73 46 C79 56 68 61 59 57 Z" fill="${p.fur}"/><path d="M73 46 C79 52 78 58 72 61 C76 55 73 50 69 47 Z" fill="${p.belly}"/>`;
    } else if (p.tail === "dog") {
      tail = `<path class="tail" d="M58 63 q9 1 8 -7" fill="none" stroke="${p.shade}" stroke-width="5.5" stroke-linecap="round"/>`;
    } else if (p.tail === "bunny") {
      tail = `<circle class="tail" cx="59" cy="65" r="4.7" fill="${p.belly}" stroke="${p.shade}" stroke-width=".9"/>`;
    } else if (p.tail === "panda") {
      tail = `<circle class="tail" cx="58" cy="64" r="3.7" fill="${patch}"/>`;
    } else if (p.tail === "hamster") {
      tail = `<circle class="tail" cx="59" cy="66" r="2.5" fill="${p.inner}"/>`;
    }

    let ears = "";
    if (p.ear === "cat") {
      ears = `<path class="ear ear-l" d="M23 34 L19.5 20 L34 27 Z" fill="${p.id === "glbani" ? patch : p.shade}"/>
        <path class="ear ear-r" d="M57 34 L60.5 20 L46 27 Z" fill="${p.shade}" style="animation-delay:.5s"/>
        <path d="M24.6 30.5 L22.9 23.6 L30.8 27.4 Z" fill="${p.inner}"/>
        <path d="M55.4 30.5 L57.1 23.6 L49.2 27.4 Z" fill="${p.inner}"/>`;
    } else if (p.ear === "fox") {
      ears = `<path class="ear ear-l" d="M22 34 L15.5 16.5 L35 26 Z" fill="${p.shade}"/>
        <path class="ear ear-r" d="M58 34 L64.5 16.5 L45 26 Z" fill="${p.shade}" style="animation-delay:.5s"/>
        <path d="M23.8 30.4 L20.8 21.8 L31 26.6 Z" fill="${p.inner}"/>
        <path d="M56.2 30.4 L59.2 21.8 L49 26.6 Z" fill="${p.inner}"/>`;
    } else if (p.ear === "bunny") {
      ears = `<ellipse class="ear ear-l" cx="31" cy="17" rx="5.5" ry="15" fill="${p.shade}" transform="rotate(-7 31 17)"/>
        <ellipse class="ear ear-r" cx="49" cy="17" rx="5.5" ry="15" fill="${p.shade}" transform="rotate(7 49 17)" style="animation-delay:.5s"/>
        <ellipse cx="31" cy="17" rx="2.8" ry="11.2" fill="${p.inner}" transform="rotate(-7 31 17)"/>
        <ellipse cx="49" cy="17" rx="2.8" ry="11.2" fill="${p.inner}" transform="rotate(7 49 17)"/>`;
    } else if (p.ear === "dog") {
      ears = `<path class="ear ear-l" d="M26 28 C16 27 12 37 16 44 C19 49 24 45 25 38 Z" fill="${p.shade}"/>
        <path class="ear ear-r" d="M54 28 C64 27 68 37 64 44 C61 49 56 45 55 38 Z" fill="${p.shade}" style="animation-delay:.5s"/>`;
    } else if (p.ear === "panda") {
      ears = `<circle class="ear ear-l" cx="26" cy="25" r="7" fill="${patch}"/>
        <circle class="ear ear-r" cx="54" cy="25" r="7" fill="${patch}" style="animation-delay:.5s"/>
        <circle cx="26" cy="25" r="3.2" fill="${p.shade}" opacity=".45"/>
        <circle cx="54" cy="25" r="3.2" fill="${p.shade}" opacity=".45"/>`;
    } else if (p.ear === "hamster") {
      ears = `<circle class="ear ear-l" cx="28" cy="27" r="6" fill="${p.shade}"/>
        <circle class="ear ear-r" cx="52" cy="27" r="6" fill="${p.shade}" style="animation-delay:.5s"/>
        <circle cx="28" cy="27" r="3" fill="${p.inner}"/>
        <circle cx="52" cy="27" r="3" fill="${p.inner}"/>`;
    }

    let bodyMarks = "";
    if (p.id === "glbani") {
      bodyMarks = `<path d="M22.5 55 q-4 5 -1 9 q6 2 7 -4 Z" fill="${patch}" opacity=".94"/>
        <path d="M52 56 q5 4 2 9 q-6 1 -6 -5 Z" fill="${patch}" opacity=".68"/>`;
    } else if (p.id === "luna") {
      bodyMarks = `<path d="M21.5 56 q-3 7 2 10 q7 1 7 -6 Z" fill="${patch}"/>
        <path d="M58.5 56 q3 7 -2 10 q-7 1 -7 -6 Z" fill="${patch}"/>`;
    }

    let headMarks = "";
    if (p.face === "cat" || p.face === "glbani") {
      headMarks = `<path d="M33 27 q3 -2.4 6 0 M41 26.4 q3 -2.4 6 0" stroke="${p.shade}" stroke-width="2" fill="none" stroke-linecap="round"/>`;
      if (p.face === "glbani") {
        headMarks += `<path d="M21.5 31 q4 -8 11 -5 q4 2 2 6 q-6 2 -13 -1 Z" fill="${patch}" opacity=".94"/>`;
      }
    } else if (p.face === "fox") {
      headMarks = `<path d="M27.5 40 Q40 34 52.5 40 Q48 49 40 49 Q32 49 27.5 40 Z" fill="${p.belly}" opacity=".94"/>
        <path d="M33 27 q3 -2.4 6 0 M41 26.4 q3 -2.4 6 0" stroke="${p.shade}" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    } else if (p.face === "dog") {
      headMarks = `<ellipse cx="48" cy="32" rx="5.4" ry="4.2" fill="${patch}" opacity=".55" transform="rotate(18 48 32)"/>`;
    } else if (p.face === "panda") {
      headMarks = `<ellipse cx="33.5" cy="39.5" rx="7" ry="8" fill="${patch}" transform="rotate(-16 33.5 39.5)"/>
        <ellipse cx="46.5" cy="39.5" rx="7" ry="8" fill="${patch}" transform="rotate(16 46.5 39.5)"/>`;
    } else if (p.face === "bunny") {
      headMarks = `<path d="M36 26 q4 -5 8 0" stroke="${p.shade}" stroke-width="1.7" fill="none" stroke-linecap="round"/>`;
    }

    let eyeBack = "";
    if (p.face === "panda") {
      eyeBack = `<circle cx="34" cy="39" r="4.7" fill="#fbfbf8"/><circle cx="46" cy="39" r="4.7" fill="#fbfbf8"/>`;
    } else if (p.face === "frog") {
      eyeBack = `<circle cx="34" cy="38" r="5.3" fill="#ffffff"/><circle cx="46" cy="38" r="5.3" fill="#ffffff"/>`;
    }
    const eyes = `${eyeBack}
      <ellipse class="eye" cx="34" cy="39" rx="2.5" ry="3.1" fill="${ink}"/>
      <ellipse class="eye" cx="46" cy="39" rx="2.5" ry="3.1" fill="${ink}"/>
      <path class="eye-happy" d="M31.4 40 q2.6 -2.8 5.2 0" stroke="${ink}" stroke-width="1.8" fill="none" stroke-linecap="round"/>
      <path class="eye-happy" d="M43.4 40 q2.6 -2.8 5.2 0" stroke="${ink}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`;

    let face = "";
    if (p.face === "cat" || p.face === "glbani") {
      face = `${eyes}
        <circle cx="29.5" cy="44.5" r="2.8" fill="${p.inner}" opacity=".55"/>
        <circle cx="50.5" cy="44.5" r="2.8" fill="${p.inner}" opacity=".55"/>
        <path d="M38.6 43.6 h2.8 l-1.4 1.9 Z" fill="#e07a8a"/>
        <path d="M40 45.7 q-2.6 2.6 -4.6 0 M40 45.7 q2.6 2.6 4.6 0" stroke="#b56b4a" fill="none" stroke-width="1.1" stroke-linecap="round"/>
        <path d="M21.5 40 h-5.5 M21.8 43.6 l-5.4 1.8 M58.5 40 h5.5 M58.2 43.6 l5.4 1.8" stroke="${whisker}" stroke-width="1.1" stroke-linecap="round"/>`;
    } else if (p.face === "bunny") {
      face = `${eyes}
        <circle cx="29.5" cy="44.5" r="2.8" fill="${p.inner}" opacity=".5"/>
        <circle cx="50.5" cy="44.5" r="2.8" fill="${p.inner}" opacity=".5"/>
        <path d="M38.6 43.6 h2.8 l-1.4 1.9 Z" fill="#e68a9a"/>
        <path d="M40 45.5 v1.2" stroke="#b56b4a" stroke-width="1" stroke-linecap="round"/>
        <rect x="38.1" y="46.8" width="1.7" height="3" rx=".5" fill="#fffdf8" stroke="#d9c4b2" stroke-width=".4"/>
        <rect x="40.2" y="46.8" width="1.7" height="3" rx=".5" fill="#fffdf8" stroke="#d9c4b2" stroke-width=".4"/>
        <path d="M21.5 40 h-5.5 M21.8 43.6 l-5.4 1.8 M58.5 40 h5.5 M58.2 43.6 l5.4 1.8" stroke="${whisker}" stroke-width="1" stroke-linecap="round"/>`;
    } else if (p.face === "dog") {
      face = `${eyes}
        <ellipse cx="40" cy="44" rx="3.1" ry="2.2" fill="#252b31"/>
        <path d="M40 46.2 v1.1" stroke="#4b2f25" stroke-width="1" stroke-linecap="round"/>
        <path d="M37.9 47.2 q2.1 5.6 4.2 0" fill="#ef7f8e"/>
        <path d="M22 40 l-4.8 -1 M22 43 l-5 1.7 M58 40 l4.8 -1 M58 43 l5 1.7" stroke="${whisker}" stroke-width="1" stroke-linecap="round" opacity=".7"/>`;
    } else if (p.face === "fox") {
      face = `${eyes}
        <ellipse cx="40" cy="44" rx="2.6" ry="1.8" fill="${ink}"/>
        <path d="M40 45.8 q-2.4 2 -4.3 0 M40 45.8 q2.4 2 4.3 0" stroke="#6b4a36" fill="none" stroke-width="1" stroke-linecap="round"/>
        <path d="M21.5 40 h-5.5 M21.8 43.6 l-5.4 1.8 M58.5 40 h5.5 M58.2 43.6 l5.4 1.8" stroke="${whisker}" stroke-width="1" stroke-linecap="round"/>`;
    } else if (p.face === "panda") {
      face = `${eyes}
        <path d="M38.5 43.6 h3 l-1.5 1.8 Z" fill="${ink}"/>
        <path d="M40 45.4 q-2.2 1.8 -3.8 0 M40 45.4 q2.2 1.8 3.8 0" stroke="${ink}" fill="none" stroke-width="1.1" stroke-linecap="round"/>`;
    } else if (p.face === "hamster") {
      face = `${eyes}
        <circle cx="28.6" cy="44" r="4.3" fill="${p.inner}" opacity=".35"/>
        <circle cx="51.4" cy="44" r="4.3" fill="${p.inner}" opacity=".35"/>
        <path d="M38.8 43.8 h2.4 l-1.2 1.6 Z" fill="#d98a96"/>
        <path d="M40 45.4 q-1.6 1.8 -2.8 0 M40 45.4 q1.6 1.8 2.8 0" stroke="#a36348" fill="none" stroke-width="1" stroke-linecap="round"/>
        <path d="M21.5 40 h-5.5 M21.8 43.6 l-5.4 1.8 M58.5 40 h5.5 M58.2 43.6 l5.4 1.8" stroke="${whisker}" stroke-width="1" stroke-linecap="round"/>`;
    } else if (p.face === "frog") {
      face = `${eyes}
        <circle cx="35.2" cy="44.8" r=".9" fill="${ink}" opacity=".62"/>
        <circle cx="44.8" cy="44.8" r=".9" fill="${ink}" opacity=".62"/>
        <path d="M31 45.5 Q40 52 49 45.5" fill="none" stroke="${ink}" stroke-width="1.5" stroke-linecap="round"/>
        <path d="M33.5 48.7 q1.5 1.1 3 0 M43.5 48.7 q1.5 1.1 3 0" stroke="${ink}" fill="none" stroke-width="1" stroke-linecap="round" opacity=".7"/>`;
    }

    const book = `<g class="book">
      <path d="M29 57 L39 55 L39 67 L29 69 Z" fill="#f8fafc"/>
      <path d="M51 57 L41 55 L41 67 L51 69 Z" fill="#e8eef5"/>
      <path class="page" d="M41 55.5 L50.5 56.8 L50.5 67.6 L41 66.4 Z" fill="#ffffff"/>
      <path d="M40 55 v12" stroke="#c3d2e0" stroke-width="1.4"/>
      <path d="M32 60 h5 M32 63 h5 M44 60 h5 M44 63 h5" stroke="#9db1c6" stroke-width="1" stroke-linecap="round"/>
    </g>`;
    const zzz = `<g class="zzz" aria-hidden="true">
      <text x="54" y="25" font-size="10.5" font-weight="700" fill="#9fb3c8" font-family="ui-sans-serif,sans-serif">z</text>
      <text x="60" y="17" font-size="8.5" font-weight="700" fill="#9fb3c8" font-family="ui-sans-serif,sans-serif">z</text>
      <text x="66" y="10" font-size="6.5" font-weight="700" fill="#9fb3c8" font-family="ui-sans-serif,sans-serif">z</text>
    </g>`;
    const acc = `<g class="acc acc-scarf">
        <path d="M27 51 q13 6 26 0 l1 5 q-14 6 -28 0 Z" fill="#ef5b5b"/>
        <path d="M50 55 l4 9 l-5 1 l-3 -8 Z" fill="#d94848"/>
      </g>
      <g class="acc acc-glasses">
        <circle cx="34" cy="39" r="5.4" fill="none" stroke="#20303f" stroke-width="1.4" opacity=".85"/>
        <circle cx="46" cy="39" r="5.4" fill="none" stroke="#20303f" stroke-width="1.4" opacity=".85"/>
        <path d="M39.4 39 h1.2" stroke="#20303f" stroke-width="1.4" opacity=".85"/>
      </g>
      <g class="acc acc-cap">
        <path d="M24 24 L40 17 L56 24 L40 31 Z" fill="#20303f"/>
        <path d="M40 26 v7" stroke="#20303f" stroke-width="2"/>
        <path d="M52 26 l0 7" stroke="#fbbf24" stroke-width="1.6"/>
        <circle cx="52" cy="33.5" r="1.6" fill="#fbbf24"/>
      </g>`;

    return `<svg viewBox="0 0 80 80" class="pet${mini ? " pet-thumb" : ""}" aria-hidden="true">
      ${tail}
      <ellipse cx="40" cy="61" rx="20" ry="15" fill="${p.shade}"/>
      <ellipse cx="40" cy="64" rx="12" ry="9" fill="${p.belly}"/>
      ${bodyMarks}
      ${book}
      <ellipse cx="31" cy="73" rx="6.5" ry="3.8" fill="${p.fur}"/>
      <ellipse cx="49" cy="73" rx="6.5" ry="3.8" fill="${p.fur}"/>
      <g class="head">
        ${ears}
        <circle cx="40" cy="40" r="17.5" fill="${p.fur}"/>
        ${headMarks}
        ${face}
      </g>
      ${zzz}
      ${acc}
    </svg>`;
  }

  let logoSeq = 0;
  let lastIconLogo = null;

  const isHex = v => /^#[0-9a-f]{6}$/i.test(String(v || "").trim());
  const normHex = (v, fallback) => isHex(v) ? String(v).trim().toLowerCase() : fallback;
  const clampNum = (v, min, max, fallback) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
  };

  function hexToRgb(hex) {
    const h = normHex(hex, "#4ade80").slice(1);
    return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
  }
  function rgba(hex, a) {
    const c = hexToRgb(hex);
    return `rgba(${c.r},${c.g},${c.b},${a})`;
  }
  function shade(hex, percent) {
    const { r, g, b } = hexToRgb(hex);
    const mix = c => percent < 0
      ? Math.round(c * (1 + percent / 100))
      : Math.round(c + (255 - c) * (percent / 100));
    const h = v => Math.max(0, Math.min(255, v)).toString(16).padStart(2, "0");
    return `#${h(mix(r))}${h(mix(g))}${h(mix(b))}`;
  }

  function accentHex() {
    if (S.settings.accent === "custom") return normHex(S.settings.accentCustom, ACCENTS.mint);
    return ACCENTS[S.settings.accent] || ACCENTS.mint;
  }

  function logoVariant(id) {
    return LOGO_VARIANTS.find(v => v.id === id) || LOGO_VARIANTS[0];
  }

  function logoSVG(id, size = 38) {
    const v = logoVariant(id);
    const t = LOGO_TONES[v.tone] || LOGO_TONES.mint;
    const gid = `lg${++logoSeq}`;
    const cid = `lc${logoSeq}`;
    return `<svg viewBox="0 0 64 64" width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="${t.g1}"/><stop offset="1" stop-color="${t.g2}"/>
        </linearGradient>
        <clipPath id="${cid}"><rect x="2" y="2" width="60" height="60" rx="16"/></clipPath>
      </defs>
      <rect x="2" y="2" width="60" height="60" rx="16" fill="url(#${gid})"/>
      <g clip-path="url(#${cid})">${logoShapeFor(v.shape, t)}</g>
      <rect x="2.7" y="2.7" width="58.6" height="58.6" rx="15.3" fill="none" stroke="${t.edge}" stroke-width="1" opacity=".5"/>
    </svg>`;
  }

  function logoShapeFor(shape, t) {
    return shape === "clock" ? logoClock(t)
      : shape === "face" ? logoFace(t)
      : shape === "paw" ? logoPaw(t)
      : logoSleep(t);
  }

  function logoClock(t) {
    return `
      <path d="M17.4 26.2 L19 10.8 L30.4 19.5 Z" fill="${t.a}" stroke="${t.a2}" stroke-width="1.2" stroke-linejoin="round"/>
      <path d="M46.6 26.2 L45 10.8 L33.6 19.5 Z" fill="${t.a}" stroke="${t.a2}" stroke-width="1.2" stroke-linejoin="round"/>
      <path d="M21.7 22.9 L22.8 15.4 L28.4 19.5 Z" fill="${t.ear}"/>
      <path d="M42.3 22.9 L41.2 15.4 L35.6 19.5 Z" fill="${t.ear}"/>
      <circle cx="32" cy="35" r="15.3" fill="#071018" fill-opacity=".72" stroke="${t.a}" stroke-width="2.5"/>
      <path d="M32 35 V26.4" stroke="${t.hand}" stroke-width="2.7" stroke-linecap="round"/>
      <path d="M32 35 H39.6" stroke="${t.hand}" stroke-width="2.9" stroke-linecap="round"/>
      <circle cx="32" cy="35" r="1.9" fill="${t.hand}"/>
      <g stroke="${t.a}" stroke-width="1.25" stroke-linecap="round" opacity=".55">
        <path d="M13.1 33.7 H18.3"/><path d="M12.4 38.4 L18.3 39.6"/>
        <path d="M45.7 33.7 H50.9"/><path d="M45.7 39.6 L51.6 38.4"/>
      </g>`;
  }

  function logoFace(t) {
    return `
      <path d="M16.8 28.6 L14.4 12.2 L28.7 20.2 Z" fill="${t.a}" stroke="${t.a2}" stroke-width="1.1" stroke-linejoin="round"/>
      <path d="M47.2 28.6 L49.6 12.2 L35.3 20.2 Z" fill="${t.a}" stroke="${t.a2}" stroke-width="1.1" stroke-linejoin="round"/>
      <path d="M21.4 22.2 L20.3 16 L25.8 20 Z" fill="${t.ear}"/>
      <path d="M42.6 22.2 L43.7 16 L38.2 20 Z" fill="${t.ear}"/>
      <path d="M16.2 33.5 q0 -15.2 15.8 -15.2 q15.8 0 15.8 15.2 q0 15.2 -15.8 15.2 q-15.8 0 -15.8 -15.2 Z" fill="#071018" fill-opacity=".58" stroke="${t.a}" stroke-width="2.4"/>
      <circle cx="25.7" cy="34" r="2.1" fill="${t.hand}"/>
      <circle cx="38.3" cy="34" r="2.1" fill="${t.hand}"/>
      <path d="M32 39.5 l-2.1 2.1 h4.2 Z" fill="${t.ear}"/>
      <path d="M32 41.6 q-3 2.8 -6 1.1 M32 41.6 q3 2.8 6 1.1" fill="none" stroke="${t.hand}" stroke-width="1.35" stroke-linecap="round"/>
      <circle cx="32" cy="23.2" r="4.5" fill="none" stroke="${t.hand}" stroke-width="1.25" opacity=".82"/>
      <path d="M32 23.2 V20.8 M32 23.2 H34.2" stroke="${t.hand}" stroke-width="1.1" stroke-linecap="round" opacity=".82"/>
      <g stroke="${t.a}" stroke-width="1.2" stroke-linecap="round" opacity=".55">
        <path d="M12.2 35 H18.2"/><path d="M12.8 40 L18.5 41.2"/>
        <path d="M51.8 35 H45.8"/><path d="M51.2 40 L45.5 41.2"/>
      </g>`;
  }

  function logoPaw(t) {
    return `
      <circle cx="18.6" cy="23.2" r="5" fill="${t.a}" opacity=".92"/>
      <circle cx="28.1" cy="17.4" r="5.2" fill="${t.a}" opacity=".92"/>
      <circle cx="38.6" cy="18.2" r="5.1" fill="${t.a}" opacity=".92"/>
      <circle cx="48.1" cy="24.8" r="4.8" fill="${t.a}" opacity=".92"/>
      <circle cx="32" cy="39" r="14.2" fill="#071018" fill-opacity=".65" stroke="${t.a}" stroke-width="2.5"/>
      <path d="M32 39 V30.4" stroke="${t.hand}" stroke-width="2.7" stroke-linecap="round"/>
      <path d="M32 39 H39.6" stroke="${t.hand}" stroke-width="2.9" stroke-linecap="round"/>
      <circle cx="32" cy="39" r="1.9" fill="${t.hand}"/>
      <path d="M18 46 q14 3 28 0" fill="none" stroke="${t.a}" stroke-width="1.5" opacity=".3" stroke-linecap="round"/>`;
  }

  function logoSleep(t) {
    return `
      <path d="M13.6 43.6 q.6 -15.1 18.4 -15.1 q17.8 0 18.4 15.1 q.1 4.2 -4 4.2 H17.6 q-4.1 0 -4 -4.2 Z" fill="${t.a}" opacity=".2" stroke="${t.a}" stroke-width="1.45"/>
      <circle cx="27.2" cy="34.3" r="10.8" fill="#071018" fill-opacity=".7" stroke="${t.a}" stroke-width="2.2"/>
      <path d="M19.1 27.2 L17.6 16.7 L27.4 22.5 Z" fill="${t.a}" stroke="${t.a2}" stroke-width="1" stroke-linejoin="round"/>
      <path d="M35.3 27.2 L36.8 16.7 L27 22.5 Z" fill="${t.a}" stroke="${t.a2}" stroke-width="1" stroke-linejoin="round"/>
      <path d="M21.9 25.5 L22.5 20.2 L26 23.1 Z" fill="${t.ear}"/>
      <path d="M32.5 25.5 L31.9 20.2 L28.4 23.1 Z" fill="${t.ear}"/>
      <path d="M23.4 34.3 q2.2 1.7 4.4 0 M28.3 34.3 q2.2 1.7 4.4 0" fill="none" stroke="${t.hand}" stroke-width="1.4" stroke-linecap="round"/>
      <path d="M27 38.2 l-1.4 1.5 h2.8 Z" fill="${t.ear}"/>
      <path d="M49.1 44.8 q8.2 0 7.2 -8.1 q-.8 -5 -5.8 -3.1" fill="none" stroke="${t.a}" stroke-width="2.6" stroke-linecap="round"/>
      <circle cx="48.4" cy="29.7" r="4.8" fill="none" stroke="${t.hand}" stroke-width="1.2" opacity=".72"/>
      <path d="M48.4 29.7 v-2.4 M48.4 29.7 h2.3" stroke="${t.hand}" stroke-width="1" stroke-linecap="round" opacity=".72"/>
      <g fill="${t.hand}" font-family="ui-sans-serif,sans-serif" font-weight="700">
        <text x="43.2" y="19.6" font-size="8">z</text>
        <text x="49.2" y="14.8" font-size="6.7">z</text>
        <text x="54" y="10.9" font-size="5.2">z</text>
      </g>`;
  }

  function paintAppearanceUI() {
    document.querySelectorAll(".theme-choice").forEach(b =>
      b.classList.toggle("active", b.dataset.theme === S.settings.theme));
    document.querySelectorAll(".accent-swatch").forEach(b =>
      b.classList.toggle("active", S.settings.accent === b.dataset.accent));
    document.querySelectorAll(".logo-choice").forEach(b =>
      b.classList.toggle("active", b.dataset.logo === S.settings.logo));

    const custom = $("accentCustom");
    if (custom) {
      custom.value = S.settings.accent === "custom"
        ? normHex(S.settings.accentCustom, ACCENTS.mint)
        : accentHex();
      custom.classList.toggle("active", S.settings.accent === "custom");
    }
  }

  let lastPetArtId = null;

  function paintPet() {
    const p = petVariant(S.settings.pet);
    const name = petName(p.id);
    if (el.petNameLabel && el.petNameLabel.textContent !== name) el.petNameLabel.textContent = name;
    if (el.petBtn) {
      const petLabel = `Pet ${name}`;
      const petTitle = `Give ${name} a pet`;
      if (el.petBtn.getAttribute("aria-label") !== petLabel) el.petBtn.setAttribute("aria-label", petLabel);
      if (el.petBtn.title !== petTitle) el.petBtn.title = petTitle;
    }
    if (el.feedBtn) {
      const feedTitle = `Feed ${name} a ${treatFor(p.id).one}`;
      if (el.feedBtn.title !== feedTitle) el.feedBtn.title = feedTitle;
      if (el.feedBtn.getAttribute("aria-label") !== feedTitle) el.feedBtn.setAttribute("aria-label", feedTitle);
    }
    if (el.petSvg && lastPetArtId !== p.id) {
      el.petSvg.innerHTML = petSVG(p.id);
      lastPetArtId = p.id;
    }
    if (el.setPetName) {
      if (el.setPetName.placeholder !== p.name) el.setPetName.placeholder = p.name;
      if (document.activeElement !== el.setPetName && el.setPetName.value !== name) {
        el.setPetName.value = name;
      }
    }
  }

  function buildPetGrid() {
    if (!el.petGrid) return;
    el.petGrid.innerHTML = "";
    for (const p of PET_VARIANTS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "pet-choice";
      b.dataset.pet = p.id;
      const art = document.createElement("span");
      art.className = "pet-choice-art";
      art.innerHTML = petSVG(p.id, true);
      const label = document.createElement("span");
      label.className = "pet-choice-name";
      label.textContent = petName(p.id);
      b.append(art, label);
      if (p.special) {
        const star = document.createElement("span");
        star.className = "pet-special";
        star.setAttribute("aria-hidden", "true");
        star.textContent = "★";
        b.appendChild(star);
      }
      b.addEventListener("click", () => selectPet(p.id));
      el.petGrid.appendChild(b);
    }
    paintPetChoices();
  }

  function paintPetChoices() {
    if (!el.petGrid) return;
    el.petGrid.querySelectorAll(".pet-choice").forEach(b => {
      const id = b.dataset.pet;
      const p = petVariant(id);
      const name = petName(id);
      const on = id === S.settings.pet;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
      b.setAttribute("aria-label", `Choose ${name}, ${p.kind}`);
      b.title = `${name} · ${p.kind}`;
      const label = b.querySelector(".pet-choice-name");
      if (label && label.textContent !== name) label.textContent = name;
    });
  }

  function selectPet(id) {
    if (!PET_VARIANTS.some(p => p.id === id) || id === S.settings.pet) {
      paintPet();
      paintPetChoices();
      return;
    }
    S.settings.pet = id;
    save();
    paintPet();
    paintPetChoices();
    paintBuddy();
    paintCoach();
    buddySay(`${petName(id)} is ready when you are.`, 4600);
    toast(`${escapeHtml(petName(id))} is ready to study.`);
  }

  function renderBrandLogo() {
    const box = $("brandLogo");
    if (box) box.innerHTML = logoSVG(S.settings.logo, 38);
  }

  function paintFavicon() {
    const link = $("favicon");
    if (!link) return;
    const svg = logoSVG(S.settings.logo, 64);
    link.href = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  function setDesktopIcon() {
    if (!window.focusApp || typeof window.focusApp.setIcon !== "function") return;
    const id = S.settings.logo;
    if (id === lastIconLogo) return;
    lastIconLogo = id;
    const svg = logoSVG(id, 256);
    const img = new Image();
    img.onload = () => {
      if (id !== S.settings.logo) return;
      try {
        const c = document.createElement("canvas");
        c.width = 256;
        c.height = 256;
        const x = c.getContext("2d");
        x.clearRect(0, 0, 256, 256);
        x.drawImage(img, 0, 0, 256, 256);
        window.focusApp.setIcon(c.toDataURL("image/png"));
      } catch (e) {}
    };
    img.onerror = () => {};
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  function applyAppearance() {
    if (!S.settings.theme || (S.settings.theme !== "dark" && S.settings.theme !== "light")) {
      S.settings.theme = "dark";
    }
    if (S.settings.accent !== "custom" && !ACCENTS[S.settings.accent]) S.settings.accent = "mint";
    if (!LOGO_VARIANTS.some(v => v.id === S.settings.logo)) S.settings.logo = LOGO_VARIANTS[0].id;

    const light = S.settings.theme === "light";
    document.body.classList.toggle("light", light);
    const base = accentHex();
    const acc = light ? shade(base, -22) : base;
    const root = document.documentElement;
    root.style.setProperty("--accent", acc);
    root.style.setProperty("--accent-soft", rgba(acc, .14));
    root.style.setProperty("--accent-line", rgba(acc, .38));
    root.style.setProperty("--on-accent", noteIsDark(acc) ? "#ffffff" : "#07120b");
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", light ? "#f2f3f5" : "#0a0e13");

    renderBrandLogo();
    paintFavicon();
    paintAppearanceUI();
    setDesktopIcon();
    if (map.ctx && map.w) mapDraw();
  }

  function buildLogoGrid() {
    const grid = $("logoGrid");
    if (!grid) return;
    grid.innerHTML = "";
    for (const v of LOGO_VARIANTS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "logo-choice";
      b.dataset.logo = v.id;
      b.innerHTML = `${logoSVG(v.id, 30)}<span class="name"><b>${v.shapeName}</b><span>${v.toneName}</span></span>`;
      b.addEventListener("click", () => {
        S.settings.logo = v.id;
        save();
        applyAppearance();
        toast(`${v.shapeName} · ${v.toneName}`);
      });
      grid.appendChild(b);
    }
  }

  function bindAppearance() {
    document.querySelectorAll(".theme-choice").forEach(b =>
      b.addEventListener("click", () => {
        S.settings.theme = b.dataset.theme;
        save();
        applyAppearance();
      }));
    document.querySelectorAll(".accent-swatch").forEach(b =>
      b.addEventListener("click", () => {
        S.settings.accent = b.dataset.accent;
        save();
        applyAppearance();
      }));
    const custom = $("accentCustom");
    if (custom) custom.addEventListener("input", () => {
      S.settings.accent = "custom";
      S.settings.accentCustom = custom.value;
      save();
      applyAppearance();
    });
  }

  /* ============================ first-run setup ============================ */
  function paintOnboardChoices() {
    document.querySelectorAll(".onboard-theme").forEach(b => {
      const on = b.dataset.theme === S.settings.theme;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
    document.querySelectorAll(".onboard-accent").forEach(b => {
      const on = b.dataset.accent === S.settings.accent;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });
  }

  function showOnboardStep(step) {
    const box = $("onboarding");
    if (!box) return;
    box.querySelectorAll(".onboard-step").forEach(s => {
      s.hidden = Number(s.dataset.step) !== step;
    });
    const d1 = $("onboardDot1");
    const d2 = $("onboardDot2");
    if (d1) d1.classList.toggle("on", step === 1);
    if (d2) d2.classList.toggle("on", step === 2);
  }

  function closeOnboarding() {
    const box = $("onboarding");
    const app = document.querySelector(".app");
    if (box) {
      box.classList.remove("show");
      box.hidden = true;
      box.setAttribute("aria-hidden", "true");
    }
    document.body.classList.remove("onboarding-open");
    if (app) app.inert = false;
  }

  function initOnboarding() {
    const box = $("onboarding");
    if (!box || S.settings.onboarded) return;

    const logo = $("onboardLogo");
    if (logo) logo.innerHTML = logoSVG(S.settings.logo, 44);

    const accentRow = $("onboardAccents");
    if (accentRow) {
      accentRow.innerHTML = "";
      for (const [id, color] of Object.entries(ACCENTS)) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "onboard-accent";
        b.dataset.accent = id;
        b.style.background = color;
        b.title = id.charAt(0).toUpperCase() + id.slice(1);
        b.setAttribute("aria-label", b.title + " accent");
        b.addEventListener("click", () => {
          S.settings.accent = id;
          save();
          applyAppearance();
          paintOnboardChoices();
        });
        accentRow.appendChild(b);
      }
    }

    document.querySelectorAll(".onboard-theme").forEach(b =>
      b.addEventListener("click", () => {
        S.settings.theme = b.dataset.theme;
        save();
        applyAppearance();
        paintOnboardChoices();
      })
    );

    const nameInput = $("onboardName");
    const nameError = $("onboardNameError");
    if (nameInput) nameInput.value = S.settings.name || "";

    const showNameError = () => {
      if (nameError) nameError.hidden = false;
      if (nameInput) {
        nameInput.classList.add("invalid");
        nameInput.setAttribute("aria-invalid", "true");
      }
    };
    const clearNameError = () => {
      if (nameError) nameError.hidden = true;
      if (nameInput) {
        nameInput.classList.remove("invalid");
        nameInput.setAttribute("aria-invalid", "false");
      }
    };

    const goStep2 = () => {
      const name = cleanName(nameInput ? nameInput.value : "");
      if (!name) {
        showNameError();
        if (nameInput) nameInput.focus();
        return;
      }
      clearNameError();
      S.settings.name = name;
      if (nameInput) nameInput.value = name;
      if (el.setName) el.setName.value = name;
      save();
      paintGreeting();
      showOnboardStep(2);
    };

    const next = $("onboardNext");
    if (next) next.addEventListener("click", goStep2);
    if (nameInput) {
      nameInput.addEventListener("input", clearNameError);
      nameInput.addEventListener("keydown", e => {
        if (e.key === "Enter") {
          e.preventDefault();
          goStep2();
        }
      });
    }
    const back = $("onboardBack");
    if (back) back.addEventListener("click", () => showOnboardStep(1));
    const start = $("onboardStart");
    if (start) start.addEventListener("click", () => {
      const name = cleanName(nameInput ? nameInput.value : S.settings.name);
      if (!name) {
        showOnboardStep(1);
        showNameError();
        if (nameInput) nameInput.focus();
        return;
      }
      clearNameError();
      S.settings.name = name;
      S.settings.onboarded = true;
      if (el.setName) el.setName.value = name;
      save();
      closeOnboarding();
      paintGreeting();
      buddySay(`Hi ${name}. I'm ${petName()}. Let's start small.`, 7600);
      toast(`Welcome, ${escapeHtml(name)}.`);
      markActive();
      if (matchMedia("(pointer:fine)").matches) setTimeout(() => el.todoInput.focus(), 120);
    });

    paintOnboardChoices();
    box.hidden = false;
    box.setAttribute("aria-hidden", "false");
    document.body.classList.add("onboarding-open");
    const app = document.querySelector(".app");
    if (app) app.inert = true;
    requestAnimationFrame(() => box.classList.add("show"));
    if (matchMedia("(pointer:fine)").matches) setTimeout(() => nameInput && nameInput.focus(), 180);
  }

  /* ============================ mind map ============================ */
  const map = {
    wrap: $("mapWrap"), canvas: $("mapCanvas"), edit: $("mapEdit"),
    hint: $("mapHint"), count: $("mapCount"), ctx: null,
    preview: $("mapNotePreview"), previewText: $("mapNotePreviewText"),
    previewEdit: $("mapNotePreviewEdit"),
    dpr: 1, w: 0, h: 0,
    view: { x: 0, y: 0, zoom: 1 },
    selected: null, selectedNote: null, editing: null, hasFit: false, fitAfterEdit: false,
    pointers: new Map(), drag: null, pinch: null, lastTap: null
  };
  map.ctx = map.canvas.getContext("2d");

  const MAP_FONT = 'ui-sans-serif,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
  const mapSizeCache = new Map();

  function noteDefaults(kind) {
    const sticky = kind === "free";
    return {
      text: "",
      size: sticky ? 14 : 13,
      color: sticky ? "#1f2328" : "#f8fafc",
      bg: sticky ? "#f5d98b" : "#1f2a3a",
      bold: false,
      italic: false,
      w: sticky ? 190 : 220
    };
  }

  function cleanNote(raw, kind) {
    if (!raw || typeof raw !== "object") return null;
    const text = String(raw.text == null ? "" : raw.text).slice(0, 2000);
    if (!text.trim()) return null;
    const d = noteDefaults(kind);
    return {
      text,
      size: clampNum(raw.size, 11, 32, d.size),
      color: normHex(raw.color, d.color),
      bg: normHex(raw.bg, d.bg),
      bold: !!raw.bold,
      italic: !!raw.italic,
      w: clampNum(raw.w, 130, 340, d.w)
    };
  }

  function mapEnsure() {
    if (!S.mindmap || !Array.isArray(S.mindmap.nodes) || !S.mindmap.nodes.length) {
      S.mindmap = mapDefaults();
    }
    const m = S.mindmap;
    const clean = [];
    const seen = new Set();
    for (const n of m.nodes) {
      if (!n || !Number.isFinite(n.id) || seen.has(n.id)) continue;
      seen.add(n.id);
      clean.push({
        id: n.id,
        text: String(n.text == null ? "Idea" : n.text).slice(0, 80),
        x: Number.isFinite(n.x) ? n.x : 0,
        y: Number.isFinite(n.y) ? n.y : 0,
        parent: n.parent == null ? null : n.parent,
        note: cleanNote(n.note, "node")
      });
    }
    if (!clean.length) { S.mindmap = mapDefaults(); return; }

    if (!clean.some(n => n.parent == null)) clean[0].parent = null;
    const ids = new Set(clean.map(n => n.id));
    for (const n of clean) if (n.parent != null && !ids.has(n.parent)) n.parent = null;

    // break any accidental parent loops so drawing can never hang
    for (const n of clean) {
      let p = n.parent, hops = 0;
      while (p != null && hops++ <= clean.length) {
        if (p === n.id) { n.parent = null; break; }
        const pn = clean.find(x => x.id === p);
        p = pn ? pn.parent : null;
      }
    }

    m.nodes = clean;
    const maxId = clean.reduce((a, n) => Math.max(a, n.id), 0);
    if (!Number.isFinite(m.nextId) || m.nextId <= maxId) m.nextId = maxId + 1;

    const rawNotes = Array.isArray(m.notes) ? m.notes : [];
    const notes = [];
    const seenNotes = new Set();
    for (const raw of rawNotes) {
      if (!raw || !Number.isFinite(raw.id) || seenNotes.has(raw.id)) continue;
      const note = cleanNote(raw, "free");
      if (!note) continue;
      seenNotes.add(raw.id);
      notes.push({
        id: raw.id,
        x: Number.isFinite(raw.x) ? raw.x : 0,
        y: Number.isFinite(raw.y) ? raw.y : 0,
        ...note
      });
    }
    m.notes = notes;
    const maxNoteId = notes.reduce((a, n) => Math.max(a, n.id), 0);
    if (!Number.isFinite(m.nextNoteId) || m.nextNoteId <= maxNoteId) m.nextNoteId = maxNoteId + 1;
  }

  function mapById(id) { return S.mindmap.nodes.find(n => n.id === id); }
  function mapNoteById(id) { return S.mindmap.notes.find(n => n.id === id); }
  function mapRoot() { return S.mindmap.nodes.find(n => n.parent == null) || S.mindmap.nodes[0]; }

  function mapPaintNotePreview() {
    if (!map.preview) return;
    const node = mapById(map.selected);
    if (node && node.note) {
      map.preview.hidden = false;
      map.previewText.textContent = node.note.text;
      map.preview.style.borderLeftColor = node.note.bg;
    } else {
      map.preview.hidden = true;
    }
  }

  function mapUpdateUI() {
    const nodes = S.mindmap.nodes.length;
    const notes = S.mindmap.notes.length;
    map.count.textContent = `${nodes} node${nodes === 1 ? "" : "s"} · ${notes} note${notes === 1 ? "" : "s"}`;
    const node = mapById(map.selected);
    map.hint.textContent = map.editing != null
      ? "Type, then press Enter"
      : node
        ? (node.note ? "Note attached · double-tap to rename" : "Double-tap or Enter to rename")
        : map.selectedNote != null
          ? "Double-tap or Note to edit"
          : "Tap a node or note";
    mapPaintNotePreview();
  }

  function mapClearSelection() {
    map.selected = null;
    map.selectedNote = null;
  }

  function mapWrapText(text, maxWidth) {
    const words = String(text || "Idea").trim().split(/\s+/).filter(Boolean);
    if (!words.length) return ["Idea"];
    const lines = [];
    let line = "";
    for (let word of words) {
      while (map.ctx.measureText(word).width > maxWidth) {
        let cut = word.length - 1;
        while (cut > 1 && map.ctx.measureText(word.slice(0, cut)).width > maxWidth) cut--;
        if (line) { lines.push(line); line = ""; }
        lines.push(word.slice(0, cut));
        word = word.slice(cut);
      }
      if (!word) continue;
      const test = line ? line + " " + word : word;
      if (line && map.ctx.measureText(test).width > maxWidth) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
    return lines.length ? lines : ["Idea"];
  }

  function mapNodeSize(n) {
    const isRoot = n.parent == null;
    const cacheKey = (isRoot ? "r|" : "c|") + n.text;
    const cached = mapSizeCache.get(cacheKey);
    if (cached) return cached;

    const font = `${isRoot ? 700 : 600} ${isRoot ? 14 : 13}px ${MAP_FONT}`;
    map.ctx.font = font;
    const maxText = isRoot ? 180 : 150;
    const lines = mapWrapText(n.text, maxText);
    const lineH = isRoot ? 18 : 17;
    let widest = 0;
    for (const l of lines) widest = Math.max(widest, map.ctx.measureText(l).width);
    const size = {
      w: Math.max(isRoot ? 132 : 96, Math.min(maxText + 28, widest + 28)),
      h: Math.max(isRoot ? 46 : 40, lines.length * lineH + 20),
      lines, lineH, font, isRoot
    };
    mapSizeCache.set(cacheKey, size);
    return size;
  }

  function mapRoundRect(ctx, x, y, w, h, r) {
    if (typeof ctx.roundRect === "function") {
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r);
      return;
    }
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function noteFont(note) {
    return `${note.italic ? "italic " : ""}${note.bold ? 700 : 400} ${note.size}px ${MAP_FONT}`;
  }

  function wrapNoteText(text, maxWidth, note) {
    if (note) map.ctx.font = noteFont(note);
    const lines = [];
    for (const para of String(text || "").split("\n")) {
      if (!para.trim()) { lines.push(""); continue; }
      let line = "";
      for (let word of para.trim().split(/\s+/)) {
        while (map.ctx.measureText(word).width > maxWidth) {
          let cut = word.length - 1;
          while (cut > 1 && map.ctx.measureText(word.slice(0, cut)).width > maxWidth) cut--;
          if (line) { lines.push(line); line = ""; }
          lines.push(word.slice(0, cut));
          word = word.slice(cut);
        }
        if (!word) continue;
        const test = line ? line + " " + word : word;
        if (line && map.ctx.measureText(test).width > maxWidth) {
          lines.push(line);
          line = word;
        } else {
          line = test;
        }
      }
      if (line) lines.push(line);
    }
    return lines.length ? lines : [""];
  }

  function mapNoteMetrics(note) {
    map.ctx.font = noteFont(note);
    const pad = 12;
    const top = 15;
    const maxLines = 16;
    const lines = wrapNoteText(note.text, Math.max(40, note.w - pad * 2), note);
    const clipped = lines.length > maxLines;
    const shown = lines.slice(0, maxLines);
    if (clipped && shown.length) {
      shown[shown.length - 1] = shown[shown.length - 1].replace(/\s*\S*$/, "") + "…";
    }
    const lineH = Math.round(note.size * 1.4);
    return {
      w: Math.max(130, Math.min(340, note.w)),
      h: top + shown.length * lineH + pad,
      lines: shown, lineH, pad, top, clipped
    };
  }

  function mapNoteAt(clientX, clientY) {
    const p = mapPoint({ clientX, clientY });
    const w = mapToWorld(p.sx, p.sy);
    const pad = 4 / map.view.zoom;
    const hit = n => {
      const m = mapNoteMetrics(n);
      return Math.abs(w.x - n.x) <= m.w / 2 + pad && Math.abs(w.y - n.y) <= m.h / 2 + pad;
    };
    const selected = mapNoteById(map.selectedNote);
    if (selected && hit(selected)) return selected;
    for (let i = S.mindmap.notes.length - 1; i >= 0; i--) {
      const n = S.mindmap.notes[i];
      if (n !== selected && hit(n)) return n;
    }
    return null;
  }

  function mapHitAt(clientX, clientY) {
    const note = mapNoteAt(clientX, clientY);
    if (note) return { type: "note", id: note.id };
    const node = mapNodeAt(clientX, clientY);
    if (node) return { type: "node", id: node.id };
    return null;
  }

  function noteIsDark(hex) {
    const c = hexToRgb(hex);
    return (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255 < 0.5;
  }

  function mapPalette() {
    const cs = getComputedStyle(document.body);
    const accent = normHex(cs.getPropertyValue("--accent").trim(), "#4ade80");
    const light = document.body.classList.contains("light");
    return {
      accent, light,
      edge: rgba(accent, .32),
      edgeSelected: "rgba(251,191,36,.44)",
      nodeBg: light ? "#ffffff" : "#111823",
      nodeText: light ? "#1f2328" : "#e6edf3",
      rootText: light ? "#10251a" : "#f2fbf5"
    };
  }

  function mapDrawNoteBadge(ctx, node, size) {
    const note = node.note;
    if (!note) return;
    const x = size.w / 2 - 2;
    const y = -size.h / 2 + 2;
    const r = 8;
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = note.bg;
    ctx.fill();
    ctx.lineWidth = 1.2 / map.view.zoom;
    ctx.strokeStyle = noteIsDark(note.bg) ? "rgba(255,255,255,.55)" : "rgba(0,0,0,.35)";
    ctx.stroke();
    ctx.strokeStyle = note.color;
    ctx.lineWidth = 1.1 / map.view.zoom;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x - 3.3, y - 2.4);
    ctx.lineTo(x + 3.3, y - 2.4);
    ctx.moveTo(x - 3.3, y + .2);
    ctx.lineTo(x + 3.3, y + .2);
    ctx.moveTo(x - 3.3, y + 2.8);
    ctx.lineTo(x + 1.6, y + 2.8);
    ctx.stroke();
    ctx.restore();
  }

  function mapDrawFreeNote(ctx, note, selected) {
    const m = mapNoteMetrics(note);
    const dark = noteIsDark(note.bg);
    ctx.save();
    ctx.translate(note.x, note.y);
    ctx.shadowColor = "rgba(0,0,0,.34)";
    ctx.shadowBlur = 12 / map.view.zoom;
    ctx.shadowOffsetY = 4 / map.view.zoom;
    mapRoundRect(ctx, -m.w / 2, -m.h / 2, m.w, m.h, 10);
    ctx.fillStyle = note.bg;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;

    ctx.save();
    mapRoundRect(ctx, -m.w / 2, -m.h / 2, m.w, m.h, 10);
    ctx.clip();
    ctx.fillStyle = dark ? "rgba(255,255,255,.06)" : "rgba(0,0,0,.055)";
    ctx.fillRect(-m.w / 2, -m.h / 2, m.w, 4);
    ctx.restore();

    mapRoundRect(ctx, -m.w / 2, -m.h / 2, m.w, m.h, 10);
    ctx.lineWidth = (selected ? 2.2 : 1.2) / map.view.zoom;
    ctx.strokeStyle = selected
      ? "#fbbf24"
      : dark ? "rgba(255,255,255,.22)" : "rgba(0,0,0,.22)";
    if (selected) {
      ctx.shadowColor = "rgba(251,191,36,.35)";
      ctx.shadowBlur = 12 / map.view.zoom;
    }
    ctx.stroke();
    ctx.shadowBlur = 0;

    ctx.fillStyle = note.color;
    ctx.font = noteFont(note);
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    const x = -m.w / 2 + m.pad;
    const y = -m.h / 2 + m.top;
    m.lines.forEach((line, i) => {
      if (line) ctx.fillText(line, x, y + i * m.lineH);
    });

    if (selected) {
      ctx.strokeStyle = dark ? "rgba(255,255,255,.32)" : "rgba(0,0,0,.28)";
      ctx.lineWidth = 1.1 / map.view.zoom;
      ctx.lineCap = "round";
      const rx = m.w / 2 - 7;
      const ry = m.h / 2 - 7;
      ctx.beginPath();
      ctx.moveTo(rx - 4, ry);
      ctx.lineTo(rx, ry - 4);
      ctx.moveTo(rx - 1, ry);
      ctx.lineTo(rx, ry - 1);
      ctx.stroke();
    }
    ctx.restore();
  }

  function mapDraw() {
    const ctx = map.ctx;
    if (!ctx || !map.w || !map.h) return;
    ctx.setTransform(map.dpr, 0, 0, map.dpr, 0, 0);
    ctx.clearRect(0, 0, map.w, map.h);
    ctx.save();
    ctx.translate(map.view.x, map.view.y);
    ctx.scale(map.view.zoom, map.view.zoom);

    const nodes = S.mindmap.nodes;
    const byId = new Map(nodes.map(n => [n.id, n]));
    const pal = mapPalette();

    for (const n of nodes) {
      if (n.parent == null) continue;
      const p = byId.get(n.parent);
      if (!p) continue;
      const mx = (p.x + n.x) / 2;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.bezierCurveTo(mx, p.y, mx, n.y, n.x, n.y);
      ctx.strokeStyle = n.id === map.selected || p.id === map.selected
        ? pal.edgeSelected
        : pal.edge;
      ctx.lineWidth = 2 / map.view.zoom;
      ctx.lineCap = "round";
      ctx.stroke();
    }

    for (const n of nodes) {
      const size = mapNodeSize(n);
      const sel = n.id === map.selected;
      ctx.save();
      ctx.translate(n.x, n.y);
      mapRoundRect(ctx, -size.w / 2, -size.h / 2, size.w, size.h, size.isRoot ? 14 : 11);
      ctx.fillStyle = size.isRoot ? rgba(pal.accent, .15) : pal.nodeBg;
      ctx.fill();
      ctx.lineWidth = (sel ? 2.2 : 1.3) / map.view.zoom;
      ctx.strokeStyle = sel
        ? "#fbbf24"
        : size.isRoot
          ? rgba(pal.accent, .85)
          : rgba(pal.accent, .34);
      if (sel) {
        ctx.shadowColor = "rgba(251,191,36,.35)";
        ctx.shadowBlur = 12 / map.view.zoom;
      }
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.fillStyle = size.isRoot ? pal.rootText : pal.nodeText;
      ctx.font = size.font;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      size.lines.forEach((line, i) => {
        ctx.fillText(line, 0, (i - (size.lines.length - 1) / 2) * size.lineH);
      });
      mapDrawNoteBadge(ctx, n, size);
      ctx.restore();
    }

    for (const note of S.mindmap.notes) {
      if (note.id !== map.selectedNote) mapDrawFreeNote(ctx, note, false);
    }
    const selectedNote = mapNoteById(map.selectedNote);
    if (selectedNote) mapDrawFreeNote(ctx, selectedNote, true);

    ctx.restore();
  }

  function mapResize() {
    if (!map.ctx) return;
    const r = map.wrap.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return;
    const oldW = map.w, oldH = map.h;
    const dpr = Math.min(2.5, window.devicePixelRatio || 1);
    map.w = r.width;
    map.h = r.height;
    map.dpr = dpr;
    map.canvas.width = Math.round(r.width * dpr);
    map.canvas.height = Math.round(r.height * dpr);
    map.canvas.style.width = r.width + "px";
    map.canvas.style.height = r.height + "px";
    if (oldW > 0 && oldH > 0 && (oldW !== r.width || oldH !== r.height)) {
      // keep the same world point in the middle when the canvas changes size
      map.view.x += (r.width - oldW) / 2;
      map.view.y += (r.height - oldH) / 2;
    }
    mapDraw();
  }

  function mapFitView() {
    if (!map.w || !map.h || !S.mindmap.nodes.length) return null;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const n of S.mindmap.nodes) {
      const s = mapNodeSize(n);
      minX = Math.min(minX, n.x - s.w / 2);
      minY = Math.min(minY, n.y - s.h / 2);
      maxX = Math.max(maxX, n.x + s.w / 2);
      maxY = Math.max(maxY, n.y + s.h / 2);
    }
    for (const n of S.mindmap.notes) {
      const s = mapNoteMetrics(n);
      minX = Math.min(minX, n.x - s.w / 2);
      minY = Math.min(minY, n.y - s.h / 2);
      maxX = Math.max(maxX, n.x + s.w / 2);
      maxY = Math.max(maxY, n.y + s.h / 2);
    }
    const bw = Math.max(1, maxX - minX);
    const bh = Math.max(1, maxY - minY);
    const pad = Math.max(16, Math.min(36, map.w * 0.065));
    const z = Math.max(0.25, Math.min(1.25, Math.min((map.w - pad * 2) / bw, (map.h - pad * 2) / bh)));
    return {
      zoom: z,
      x: map.w / 2 - ((minX + maxX) / 2) * z,
      y: map.h / 2 - ((minY + maxY) / 2) * z
    };
  }

  function mapFit() {
    const v = mapFitView();
    if (!v) return;
    map.view.zoom = v.zoom;
    map.view.x = v.x;
    map.view.y = v.y;
    map.hasFit = true;
    mapDraw();
  }

  function mapPoint(ev) {
    const r = map.wrap.getBoundingClientRect();
    return { sx: ev.clientX - r.left, sy: ev.clientY - r.top };
  }

  function mapToWorld(sx, sy) {
    return {
      x: (sx - map.view.x) / map.view.zoom,
      y: (sy - map.view.y) / map.view.zoom
    };
  }

  function mapNodeAt(clientX, clientY) {
    const p = mapPoint({ clientX, clientY });
    const w = mapToWorld(p.sx, p.sy);
    const pad = 4 / map.view.zoom;
    for (let i = S.mindmap.nodes.length - 1; i >= 0; i--) {
      const n = S.mindmap.nodes[i];
      const s = mapNodeSize(n);
      if (Math.abs(w.x - n.x) <= s.w / 2 + pad && Math.abs(w.y - n.y) <= s.h / 2 + pad) return n;
    }
    return null;
  }

  function mapSelect(id) {
    map.selected = id;
    map.selectedNote = null;
    mapUpdateUI();
    mapDraw();
  }

  function mapEditNode(n) {
    if (!n) return;
    if (map.editing != null) mapFinishEdit(false);
    map.selected = n.id;
    map.selectedNote = null;
    const z = map.view.zoom;
    const s = mapNodeSize(n);
    const editW = Math.max(130, Math.min(240, s.w * z + 20, map.w - 24));
    let cx = n.x * z + map.view.x;
    let cy = n.y * z + map.view.y;

    // nudge just enough to keep the editor inside the canvas
    const halfW = editW / 2 + 12;
    const halfH = 26;
    if (cx - halfW < 0) map.view.x += halfW - cx;
    else if (cx + halfW > map.w) map.view.x -= cx + halfW - map.w;
    if (cy - halfH < 0) map.view.y += halfH - cy;
    else if (cy + halfH > map.h) map.view.y -= cy + halfH - map.h;
    cx = n.x * z + map.view.x;
    cy = n.y * z + map.view.y;

    map.edit.value = n.text;
    map.edit.style.left = cx + "px";
    map.edit.style.top = cy + "px";
    map.edit.style.width = editW + "px";
    map.edit.classList.add("show");
    map.editing = n.id;
    mapUpdateUI();
    mapDraw();
    map.edit.focus({ preventScroll: true });
    map.edit.select();
  }

  function mapFinishEdit(cancel) {
    if (map.editing == null) return;
    const n = mapById(map.editing);
    const value = map.edit.value.trim();
    map.editing = null;
    map.edit.classList.remove("show");
    if (!cancel && n) {
      const text = (value || n.text || "Idea").slice(0, 80);
      if (text !== n.text) { n.text = text; save(); }
    }
    if (map.fitAfterEdit) {
      map.fitAfterEdit = false;
      const v = mapFitView();
      // only zoom out to fit when the result is still readable
      if (v && v.zoom >= 0.6) {
        map.view.zoom = v.zoom;
        map.view.x = v.x;
        map.view.y = v.y;
        map.hasFit = true;
      }
    }
    mapUpdateUI();
    mapDraw();
  }

  function mapAddNode() {
    mapEnsure();
    if (map.editing != null) mapFinishEdit(false);
    map.selectedNote = null;
    const parent = mapById(map.selected) || mapRoot();
    if (!parent) return;
    const kids = S.mindmap.nodes.filter(n => n.parent === parent.id);
    const isRoot = parent.parent == null;
    let x, y;

    if (isRoot) {
      const dirs = [[155, -125], [155, 125], [-155, -125], [-155, 125], [0, 195], [0, -205], [240, 0], [-240, 0]];
      const d = dirs[kids.length % dirs.length];
      x = parent.x + d[0];
      y = parent.y + d[1];
      if (kids.length >= dirs.length) {
        const ring = Math.floor(kids.length / dirs.length);
        x += (d[0] < 0 ? -1 : 1) * ring * 80;
        y += (d[1] < 0 ? -1 : 1) * ring * 80;
      }
    } else {
      const dir = parent.x >= 0 ? 1 : -1;
      const slot = kids.length;
      const offset = slot === 0 ? 0 : (slot % 2 ? Math.ceil(slot / 2) : -slot / 2) * 86;
      x = parent.x + dir * 220;
      y = parent.y + offset;
    }

    let guard = 0;
    while (S.mindmap.nodes.some(n => Math.abs(n.x - x) < 120 && Math.abs(n.y - y) < 55) && guard++ < 40) {
      y += 74;
      if (y > 700) { y = -700; x += 130; }
    }

    const node = { id: S.mindmap.nextId++, text: "New idea", x, y, parent: parent.id };
    S.mindmap.nodes.push(node);
    map.selected = node.id;
    save();
    mapUpdateUI();
    mapDraw();
    map.fitAfterEdit = true;
    mapEditNode(node);
  }

  function mapDeleteSelection() {
    if (map.editing != null) mapFinishEdit(false);
    const note = mapNoteById(map.selectedNote);
    if (note) {
      if (!confirm("Delete this sticky note?")) return;
      S.mindmap.notes = S.mindmap.notes.filter(n => n.id !== note.id);
      map.selectedNote = null;
      save();
      mapUpdateUI();
      mapDraw();
      return;
    }
    const n = mapById(map.selected);
    if (!n) { toast("Tap a node or note first, then delete."); return; }
    if (n.parent == null) { toast("The center node stays — delete a branch instead."); return; }
    if (!confirm(`Delete “${n.text}” and all of its branches?`)) return;

    const ids = new Set([n.id]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const x of S.mindmap.nodes) {
        if (x.parent != null && ids.has(x.parent) && !ids.has(x.id)) {
          ids.add(x.id);
          changed = true;
        }
      }
    }
    S.mindmap.nodes = S.mindmap.nodes.filter(x => !ids.has(x.id));
    save();
    mapSelect(null);
  }

  function mapReset() {
    if (!confirm("Reset the mind map to the starter layout? This also removes its notes.")) return;
    if (map.editing != null) mapFinishEdit(true);
    closeNoteEditor();
    S.mindmap = mapDefaults();
    map.selected = null;
    map.selectedNote = null;
    map.hasFit = false;
    map.fitAfterEdit = false;
    save();
    mapUpdateUI();
    mapFit();
  }

  function mapHydrate() {
    mapEnsure();
    map.selected = null;
    map.selectedNote = null;
    map.lastTap = null;
    map.hasFit = false;
    map.fitAfterEdit = false;
    closeNoteEditor();
    if (map.editing != null) {
      map.editing = null;
      map.edit.classList.remove("show");
    }
    mapUpdateUI();
  }

  function mapOnShow() {
    mapEnsure();
    mapUpdateUI();
    requestAnimationFrame(() => {
      mapResize();
      if (!map.hasFit) mapFit();
      else mapDraw();
    });
  }

  function mapPointerDown(ev) {
    if (ev.target === map.edit) return;
    if (ev.pointerType === "mouse" && ev.button !== 0) return;
    ev.preventDefault();
    map.wrap.focus({ preventScroll: true });
    try { map.wrap.setPointerCapture(ev.pointerId); } catch (e) {}
    const p = mapPoint(ev);
    map.pointers.set(ev.pointerId, { sx: p.sx, sy: p.sy });

    if (map.pointers.size === 1) {
      const hit = mapHitAt(ev.clientX, ev.clientY);
      const obj = hit && (hit.type === "node" ? mapById(hit.id) : mapNoteById(hit.id));
      if (hit && obj) {
        if (map.editing != null) mapFinishEdit(false);
        if (hit.type === "node") {
          map.selected = hit.id;
          map.selectedNote = null;
        } else {
          map.selected = null;
          map.selectedNote = hit.id;
        }
        mapUpdateUI();
        map.drag = {
          type: hit.type, id: hit.id,
          sx: p.sx, sy: p.sy, nx: obj.x, ny: obj.y, moved: false
        };
        map.wrap.style.cursor = "grabbing";
        mapDraw();
      } else {
        map.drag = {
          type: "pan", sx: p.sx, sy: p.sy,
          vx: map.view.x, vy: map.view.y, moved: false
        };
        map.wrap.classList.add("dragging");
      }
    } else if (map.pointers.size === 2) {
      if (map.drag && (map.drag.type === "node" || map.drag.type === "note") && map.drag.moved) save();
      map.drag = null;
      map.wrap.classList.remove("dragging");
      const pts = [...map.pointers.values()];
      const mx = (pts[0].sx + pts[1].sx) / 2;
      const my = (pts[0].sy + pts[1].sy) / 2;
      const dist = Math.hypot(pts[0].sx - pts[1].sx, pts[0].sy - pts[1].sy) || 1;
      map.pinch = { dist, zoom: map.view.zoom, anchor: mapToWorld(mx, my) };
      map.wrap.style.cursor = "grabbing";
    }
  }

  function mapPointerMove(ev) {
    const p = mapPoint(ev);
    if (map.pointers.has(ev.pointerId)) map.pointers.set(ev.pointerId, { sx: p.sx, sy: p.sy });

    if (map.pinch && map.pointers.size >= 2) {
      const pts = [...map.pointers.values()].slice(0, 2);
      const mx = (pts[0].sx + pts[1].sx) / 2;
      const my = (pts[0].sy + pts[1].sy) / 2;
      const dist = Math.hypot(pts[0].sx - pts[1].sx, pts[0].sy - pts[1].sy) || 1;
      const z = Math.max(0.25, Math.min(2.5, map.pinch.zoom * dist / map.pinch.dist));
      map.view.zoom = z;
      map.view.x = mx - map.pinch.anchor.x * z;
      map.view.y = my - map.pinch.anchor.y * z;
      mapDraw();
      return;
    }

    if (!map.drag) {
      if (ev.pointerType === "mouse") {
        const hit = mapHitAt(ev.clientX, ev.clientY);
        map.wrap.style.cursor = hit ? "pointer" : "grab";
      }
      return;
    }

    const dx = p.sx - map.drag.sx;
    const dy = p.sy - map.drag.sy;
    if (Math.abs(dx) + Math.abs(dy) > 4) map.drag.moved = true;

    if (map.drag.type === "node" || map.drag.type === "note") {
      const n = map.drag.type === "node" ? mapById(map.drag.id) : mapNoteById(map.drag.id);
      if (n) {
        n.x = map.drag.nx + dx / map.view.zoom;
        n.y = map.drag.ny + dy / map.view.zoom;
        mapDraw();
      }
    } else if (map.drag.type === "pan") {
      map.view.x = map.drag.vx + dx;
      map.view.y = map.drag.vy + dy;
      mapDraw();
    }
  }

  function mapPointerUp(ev) {
    const wasDrag = map.drag;
    map.pointers.delete(ev.pointerId);

    if (map.pinch) {
      if (map.pointers.size < 2) map.pinch = null;
      map.drag = null;
      map.wrap.classList.remove("dragging");
      map.wrap.style.cursor = "grab";
      return;
    }
    if (!wasDrag) return;

    map.drag = null;
    map.wrap.classList.remove("dragging");
    map.wrap.style.cursor = "grab";

    if (wasDrag.type === "node" || wasDrag.type === "note") {
      const n = wasDrag.type === "node" ? mapById(wasDrag.id) : mapNoteById(wasDrag.id);
      if (wasDrag.moved) {
        map.lastTap = null;
        save();
        mapUpdateUI();
      } else if (n) {
        const now = Date.now();
        const last = map.lastTap;
        if (last && last.type === wasDrag.type && last.id === n.id && now - last.time < 380) {
          map.lastTap = null;
          if (wasDrag.type === "node") mapEditNode(n);
          else openNoteEditor({ type: "free", id: n.id });
        } else {
          map.lastTap = { type: wasDrag.type, id: n.id, time: now };
          if (wasDrag.type === "node") {
            mapSelect(n.id);
          } else {
            map.selected = null;
            map.selectedNote = n.id;
            mapUpdateUI();
            mapDraw();
          }
        }
      }
    } else if (wasDrag.type === "pan" && !wasDrag.moved) {
      mapClearSelection();
      map.lastTap = null;
      mapUpdateUI();
      mapDraw();
    }
  }

  function mapPointerCancel(ev) {
    const wasDrag = map.drag;
    map.pointers.delete(ev.pointerId);
    if (map.pointers.size < 2) map.pinch = null;
    if (map.pointers.size === 0) {
      if (wasDrag && (wasDrag.type === "node" || wasDrag.type === "note") && wasDrag.moved) save();
      map.drag = null;
      map.wrap.classList.remove("dragging");
      map.wrap.style.cursor = "grab";
    }
  }

  $("mapAdd").addEventListener("click", mapAddNode);
  $("mapAddNote").addEventListener("click", mapAddNote);
  $("mapNote").addEventListener("click", mapEditSelectedNote);
  $("mapDelete").addEventListener("click", mapDeleteSelection);
  $("mapRename").addEventListener("click", () => {
    const n = mapById(map.selected);
    if (n) mapEditNode(n);
    else if (map.selectedNote != null) toast("Use Note to edit a sticky note.");
    else toast("Tap a node first, then rename.");
  });
  $("mapFit").addEventListener("click", mapFit);
  $("mapReset").addEventListener("click", mapReset);
  if (map.previewEdit) map.previewEdit.addEventListener("click", () => {
    const n = mapById(map.selected);
    if (n) openNoteEditor({ type: "node", id: n.id });
  });

  map.wrap.addEventListener("pointerdown", mapPointerDown);
  map.wrap.addEventListener("pointermove", mapPointerMove);
  map.wrap.addEventListener("pointerup", mapPointerUp);
  map.wrap.addEventListener("pointercancel", mapPointerCancel);

  map.wrap.addEventListener("wheel", ev => {
    if (map.editing != null) return;
    ev.preventDefault();
    const p = mapPoint(ev);
    const before = mapToWorld(p.sx, p.sy);
    const dy = ev.deltaMode === 1 ? ev.deltaY * 16 : ev.deltaY;
    const factor = Math.exp(-dy * 0.0015);
    map.view.zoom = Math.max(0.25, Math.min(2.5, map.view.zoom * factor));
    map.view.x = p.sx - before.x * map.view.zoom;
    map.view.y = p.sy - before.y * map.view.zoom;
    mapDraw();
  }, { passive: false });

  map.wrap.addEventListener("keydown", ev => {
    if (map.editing != null) return;
    if (ev.code === "Space") { ev.preventDefault(); return; }
    if (ev.ctrlKey || ev.metaKey || ev.altKey) return;
    if (ev.key === "Enter") {
      const n = mapById(map.selected);
      if (n) { ev.preventDefault(); mapEditNode(n); }
      else if (map.selectedNote != null) { ev.preventDefault(); mapEditSelectedNote(); }
    } else if (ev.key === "Delete" || ev.key === "Backspace") {
      ev.preventDefault();
      mapDeleteSelection();
    } else if (ev.key === "n" || ev.key === "N" || ev.key === "+") {
      ev.preventDefault();
      mapAddNode();
    } else if (ev.key === "m" || ev.key === "M") {
      ev.preventDefault();
      mapAddNote();
    } else if (ev.key === "e" || ev.key === "E") {
      ev.preventDefault();
      mapEditSelectedNote();
    } else if (ev.key === "f" || ev.key === "F") {
      ev.preventDefault();
      mapFit();
    }
  });

  map.edit.addEventListener("keydown", ev => {
    ev.stopPropagation();
    if (ev.key === "Enter") {
      ev.preventDefault();
      mapFinishEdit(false);
      map.wrap.focus({ preventScroll: true });
    } else if (ev.key === "Escape") {
      ev.preventDefault();
      mapFinishEdit(true);
      map.wrap.focus({ preventScroll: true });
    }
  });
  map.edit.addEventListener("blur", () => mapFinishEdit(false));

  if (window.ResizeObserver) {
    new ResizeObserver(() => {
      if ($("panel-mindmap").classList.contains("active")) mapResize();
    }).observe(map.wrap);
  }
  window.addEventListener("resize", () => {
    if ($("panel-mindmap").classList.contains("active")) mapResize();
  });

  /* ============================ notes ============================ */
  const NOTE_TEXT_COLORS = ["#f8fafc", "#1f2328", "#4ade80", "#60a5fa", "#f472b6", "#fbbf24"];
  const NOTE_BG_COLORS = ["#1f2a3a", "#243b2f", "#2b2440", "#f5d98b", "#f7c6d9", "#bfe3f7", "#d7f0c2", "#ffffff"];
  const noteUI = {
    modal: $("noteModal"), title: $("noteTitle"), sub: $("noteSub"),
    text: $("noteText"), size: $("noteSize"), sizeText: $("noteSizeText"),
    textColors: $("noteTextColors"), textColor: $("noteTextColor"),
    bgColors: $("noteBgColors"), bgColor: $("noteBgColor"),
    bold: $("noteBold"), italic: $("noteItalic"),
    widthWrap: $("noteWidthWrap"), width: $("noteWidth"), widthText: $("noteWidthText"),
    del: $("noteDelete"), cancel: $("noteCancel"), close: $("noteClose"), save: $("noteSave")
  };
  let noteDraft = null;
  let noteTarget = null;

  function mapAddNote() {
    mapEnsure();
    if (map.editing != null) mapFinishEdit(false);
    const cx = (map.w / 2 - map.view.x) / map.view.zoom;
    const cy = (map.h / 2 - map.view.y) / map.view.zoom;
    const offset = (S.mindmap.notes.length % 5) * 18;
    openNoteEditor({
      type: "free", id: null, isNew: true,
      x: cx + 34 + offset, y: cy + 18 + offset
    });
  }

  function mapEditSelectedNote() {
    const note = mapNoteById(map.selectedNote);
    if (note) { openNoteEditor({ type: "free", id: note.id }); return; }
    const node = mapById(map.selected);
    if (node) { openNoteEditor({ type: "node", id: node.id }); return; }
    toast("Tap a node or sticky note first.");
  }

  function buildNotePalette() {
    for (const color of NOTE_TEXT_COLORS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "note-swatch";
      b.dataset.color = color;
      b.style.background = color;
      b.title = color;
      b.setAttribute("aria-label", "Text color " + color);
      b.addEventListener("click", () => {
        if (!noteDraft) return;
        noteDraft.color = color;
        syncNoteEditor();
      });
      noteUI.textColors.insertBefore(b, noteUI.textColor);
    }
    for (const color of NOTE_BG_COLORS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "note-swatch";
      b.dataset.color = color;
      b.style.background = color;
      b.title = color;
      b.setAttribute("aria-label", "Note color " + color);
      b.addEventListener("click", () => {
        if (!noteDraft) return;
        noteDraft.bg = color;
        syncNoteEditor();
      });
      noteUI.bgColors.insertBefore(b, noteUI.bgColor);
    }
  }

  function syncNoteEditor() {
    if (!noteDraft) return;
    const d = noteDraft;
    noteUI.text.style.background = d.bg;
    noteUI.text.style.color = d.color;
    noteUI.text.style.fontSize = d.size + "px";
    noteUI.text.style.fontWeight = d.bold ? "700" : "400";
    noteUI.text.style.fontStyle = d.italic ? "italic" : "normal";
    noteUI.size.value = d.size;
    noteUI.sizeText.textContent = d.size;
    noteUI.width.value = d.w;
    noteUI.widthText.textContent = d.w;
    noteUI.textColor.value = d.color;
    noteUI.bgColor.value = d.bg;
    noteUI.bold.classList.toggle("active", d.bold);
    noteUI.bold.setAttribute("aria-pressed", d.bold ? "true" : "false");
    noteUI.italic.classList.toggle("active", d.italic);
    noteUI.italic.setAttribute("aria-pressed", d.italic ? "true" : "false");
    noteUI.textColors.querySelectorAll(".note-swatch").forEach(b =>
      b.classList.toggle("active", String(b.dataset.color).toLowerCase() === d.color.toLowerCase()));
    noteUI.bgColors.querySelectorAll(".note-swatch").forEach(b =>
      b.classList.toggle("active", String(b.dataset.color).toLowerCase() === d.bg.toLowerCase()));
  }

  function openNoteEditor(target) {
    if (!noteUI.modal) return;
    if (map.editing != null) mapFinishEdit(false);
    let draft, title, sub, existing = false;
    if (target.type === "node") {
      const node = mapById(target.id);
      if (!node) return;
      existing = !!node.note;
      draft = node.note ? { ...node.note } : noteDefaults("node");
      title = existing ? "Node note" : "New node note";
      sub = `Attached to “${node.text}”. It stays with this node on the canvas.`;
      map.selected = node.id;
      map.selectedNote = null;
    } else {
      const note = target.id == null ? null : mapNoteById(target.id);
      if (target.id != null && !note) return;
      existing = !!note;
      draft = note ? { ...note } : {
        ...noteDefaults("free"),
        x: Number.isFinite(target.x) ? target.x : 0,
        y: Number.isFinite(target.y) ? target.y : 0
      };
      title = existing ? "Sticky note" : "New sticky note";
      sub = "A free note on the canvas. Drag it anywhere, or change its width.";
      if (note) {
        map.selected = null;
        map.selectedNote = note.id;
      }
    }
    noteDraft = draft;
    noteTarget = { type: target.type, id: target.id, isNew: !existing };
    noteUI.title.textContent = title;
    noteUI.sub.textContent = sub;
    noteUI.text.value = draft.text || "";
    noteUI.widthWrap.classList.toggle("hidden", target.type !== "free");
    noteUI.del.textContent = "Delete note";
    noteUI.del.style.display = noteTarget.isNew ? "none" : "";
    noteUI.save.textContent = noteTarget.isNew ? "Add note" : "Save note";
    syncNoteEditor();
    noteUI.modal.classList.add("show");
    noteUI.modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("note-open");
    mapUpdateUI();
    mapDraw();
    setTimeout(() => {
      noteUI.text.focus({ preventScroll: true });
      noteUI.text.setSelectionRange(noteUI.text.value.length, noteUI.text.value.length);
    }, 60);
  }

  function closeNoteEditor() {
    if (!noteUI.modal) return;
    noteUI.modal.classList.remove("show");
    noteUI.modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("note-open");
    noteDraft = null;
    noteTarget = null;
  }

  function saveNoteEditor() {
    if (!noteDraft || !noteTarget) return;
    const text = noteUI.text.value;
    if (!text.trim()) {
      toast("Write something first.");
      noteUI.text.focus();
      return;
    }
    noteDraft.text = text;
    const clean = cleanNote(noteDraft, noteTarget.type === "free" ? "free" : "node");
    if (!clean) return;
    if (noteTarget.type === "node") {
      const node = mapById(noteTarget.id);
      if (!node) { closeNoteEditor(); return; }
      node.note = clean;
      map.selected = node.id;
      map.selectedNote = null;
    } else if (noteTarget.isNew) {
      const id = S.mindmap.nextNoteId++;
      S.mindmap.notes.push({
        id,
        x: Number.isFinite(noteDraft.x) ? noteDraft.x : 0,
        y: Number.isFinite(noteDraft.y) ? noteDraft.y : 0,
        ...clean
      });
      map.selected = null;
      map.selectedNote = id;
    } else {
      const note = mapNoteById(noteTarget.id);
      if (!note) { closeNoteEditor(); return; }
      Object.assign(note, clean);
      map.selected = null;
      map.selectedNote = note.id;
    }
    const wasNew = !!noteTarget.isNew;
    save();
    closeNoteEditor();
    mapUpdateUI();
    mapDraw();
    toast(wasNew ? "Note added." : "Note saved.");
  }

  function deleteNoteEditor() {
    if (!noteDraft || !noteTarget) return;
    if (noteTarget.isNew) { closeNoteEditor(); return; }
    if (noteTarget.type === "node") {
      const node = mapById(noteTarget.id);
      if (node) node.note = null;
    } else {
      S.mindmap.notes = S.mindmap.notes.filter(n => n.id !== noteTarget.id);
      if (map.selectedNote === noteTarget.id) map.selectedNote = null;
    }
    save();
    closeNoteEditor();
    mapUpdateUI();
    mapDraw();
    toast("Note deleted.");
  }

  if (noteUI.modal) {
    buildNotePalette();
    noteUI.text.addEventListener("input", () => {
      if (noteDraft) noteDraft.text = noteUI.text.value;
    });
    noteUI.size.addEventListener("input", () => {
      if (!noteDraft) return;
      noteDraft.size = Number(noteUI.size.value);
      noteUI.sizeText.textContent = noteDraft.size;
      syncNoteEditor();
    });
    noteUI.width.addEventListener("input", () => {
      if (!noteDraft) return;
      noteDraft.w = Number(noteUI.width.value);
      noteUI.widthText.textContent = noteDraft.w;
      syncNoteEditor();
    });
    noteUI.textColor.addEventListener("input", () => {
      if (!noteDraft) return;
      noteDraft.color = noteUI.textColor.value;
      syncNoteEditor();
    });
    noteUI.bgColor.addEventListener("input", () => {
      if (!noteDraft) return;
      noteDraft.bg = noteUI.bgColor.value;
      syncNoteEditor();
    });
    noteUI.bold.addEventListener("click", () => {
      if (!noteDraft) return;
      noteDraft.bold = !noteDraft.bold;
      syncNoteEditor();
    });
    noteUI.italic.addEventListener("click", () => {
      if (!noteDraft) return;
      noteDraft.italic = !noteDraft.italic;
      syncNoteEditor();
    });
    noteUI.save.addEventListener("click", saveNoteEditor);
    noteUI.del.addEventListener("click", deleteNoteEditor);
    noteUI.cancel.addEventListener("click", closeNoteEditor);
    noteUI.close.addEventListener("click", closeNoteEditor);
    noteUI.modal.addEventListener("click", ev => {
      if (ev.target === noteUI.modal) closeNoteEditor();
    });
    noteUI.modal.addEventListener("keydown", ev => {
      ev.stopPropagation();
      if (ev.key === "Escape") {
        ev.preventDefault();
        closeNoteEditor();
      } else if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) {
        ev.preventDefault();
        saveNoteEditor();
      }
    });
  }

  /* ============================ tabs ============================ */
  function switchTab(name) {
    if (name !== "mindmap" && map.editing != null) mapFinishEdit(false);
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name));
    document.querySelectorAll(".panel").forEach(p => p.classList.toggle("active", p.id === "panel-" + name));
    if (name === "mindmap") mapOnShow();
  }

  /* ============================ wiring ============================ */
  function toggleTimer() {
    try { getCtx(); } catch (e) {} // unlock audio on the first gesture
    if (S.timer.running) {
      pause();
      buddySay("Paused. I'll wait.", 3000);
    } else {
      run();
      buddySay(S.timer.mode === "work" ? "Okay. We're doing this." : "Break. Stand up, human.", 0);
    }
  }

  el.startBtn.addEventListener("click", toggleTimer);

  el.resetBtn.addEventListener("click", resetTimer);
  el.skipBtn.addEventListener("click", skip);

  el.petBtn.addEventListener("click", () => {
    el.petBtn.classList.remove("petting");
    void el.petBtn.offsetWidth;
    el.petBtn.classList.add("petting");
    setTimeout(() => el.petBtn.classList.remove("petting"), 900);
    spawnHearts();
    buddySay(pickLine(BUDDY_LINES.pet), 2600);
    markActive();
    try { getCtx(); } catch (e) {}
  });

  if (el.feedBtn) el.feedBtn.addEventListener("click", feedPet);

  document.querySelectorAll(".track").forEach(btn =>
    btn.addEventListener("click", () => toggleTrack(btn.dataset.track))
  );

  el.musicStop.addEventListener("click", () => {
    Music.stop();
    paintMusic(null);
  });

  el.musicVol.addEventListener("input", () => {
    S.settings.musicVolume = Number(el.musicVol.value);
    el.musicVolText.textContent = S.settings.musicVolume + "%";
    Music.setVolume(S.settings.musicVolume);
    save();
  });

  if (window.focusApp) {
    el.miniBtn.addEventListener("click", () => window.focusApp.toggleMini());
    const applyMini = on => {
      if (on) switchTab("focus");
      document.body.classList.toggle("mini", on);
    };
    window.focusApp.onMini(applyMini);
    window.focusApp.getMini().then(applyMini).catch(() => {});
  } else {
    el.miniBtn.style.display = "none";
  }

  document.querySelectorAll(".tab").forEach(t =>
    t.addEventListener("click", () => switchTab(t.dataset.tab))
  );

  el.todoForm.addEventListener("submit", e => {
    e.preventDefault();
    addTodo();
  });
  el.todoClear.addEventListener("click", clearDoneTodos);

  if (el.focusTaskClear) {
    el.focusTaskClear.addEventListener("click", () => {
      S.focusTask = null;
      save();
      paintTodos();
      paintFocusTask();
      paintCoach();
      toast("Task unlinked. The timer still works.");
    });
  }

  if (el.coachNext) {
    el.coachNext.addEventListener("click", () => {
      coachVariant += 1;
      paintCoach();
    });
  }
  if (el.coachPick) el.coachPick.addEventListener("click", pickCoachTask);

  if (el.setExamName) {
    el.setExamName.addEventListener("input", () => {
      S.settings.examName = cleanExam(el.setExamName.value);
      save();
      paintExam();
      paintCoach();
    });
    el.setExamName.addEventListener("blur", () => {
      const name = cleanExam(el.setExamName.value);
      el.setExamName.value = name;
      S.settings.examName = name;
      save();
      paintExam();
      paintCoach();
    });
  }
  if (el.setExamDate) {
    el.setExamDate.addEventListener("change", () => {
      S.settings.examDate = validExamDate(el.setExamDate.value);
      el.setExamDate.value = S.settings.examDate;
      save();
      paintExam();
      paintCoach();
    });
  }
  if (el.examClear) {
    el.examClear.addEventListener("click", () => {
      S.settings.examName = "";
      S.settings.examDate = "";
      if (el.setExamName) el.setExamName.value = "";
      if (el.setExamDate) el.setExamDate.value = "";
      save();
      paintExam();
      paintCoach();
      toast("Exam countdown cleared.");
    });
  }

  if (el.exportBackup) el.exportBackup.addEventListener("click", exportBackup);
  if (el.importBackup) el.importBackup.addEventListener("click", () => el.importFile && el.importFile.click());
  if (el.importFile) el.importFile.addEventListener("change", importBackupFile);

  el.journalAdd.addEventListener("click", () => {
    const text = el.journalInput.value.trim();
    if (!text) return;
    S.journal.unshift({
      id: Date.now().toString(36),
      text,
      date: new Date().toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
    });
    if (S.journal.length > 300) S.journal.length = 300;
    el.journalInput.value = "";
    paintJournal();
    save();
    toast("Logged. Review it before the next session.");
  });

  el.journalList.addEventListener("click", ev => {
    const btn = ev.target.closest(".del");
    if (!btn) return;
    S.journal = S.journal.filter(e => e.id !== btn.dataset.id);
    paintJournal();
    save();
  });

  numField(el.setWork, "work", 1, 120);
  numField(el.setShort, "short", 1, 30);
  numField(el.setLong, "long", 1, 60);
  numField(el.setBlocks, "blocks", 1, 8);
  numField(el.setGoal, "dailyGoal", 1, 20);

  el.setAuto.addEventListener("change", () => { S.settings.auto = el.setAuto.checked; save(); });
  el.setSound.addEventListener("change", () => { S.settings.sound = el.setSound.checked; save(); });

  el.setSoundStyle.addEventListener("change", () => {
    S.settings.soundStyle = el.setSoundStyle.value;
    save();
    beep(true, true);
  });

  el.setVolume.addEventListener("input", () => {
    S.settings.volume = Number(el.setVolume.value);
    el.volText.textContent = S.settings.volume + "%";
    save();
  });
  el.setVolume.addEventListener("change", () => beep(true, true));

  el.testSound.addEventListener("click", () => beep(true, true));

  el.setBuddy.addEventListener("change", () => {
    S.settings.buddy = el.setBuddy.checked;
    paintBuddy();
    save();
  });

  if (el.setName) {
    el.setName.addEventListener("input", () => {
      S.settings.name = el.setName.value.slice(0, 24);
      save();
      paintGreeting();
    });
    el.setName.addEventListener("blur", () => {
      const name = cleanName(el.setName.value);
      el.setName.value = name;
      S.settings.name = name;
      save();
      paintGreeting();
    });
  }

  if (el.setPetName) {
    const applyPetName = () => {
      const id = S.settings.pet;
      const value = cleanName(el.setPetName.value);
      if (value) S.settings.petNames[id] = value;
      else delete S.settings.petNames[id];
      save();
      paintPet();
      paintPetChoices();
      paintCoach();
    };
    el.setPetName.addEventListener("input", applyPetName);
    el.setPetName.addEventListener("blur", () => {
      applyPetName();
      el.setPetName.value = petName();
    });
  }

  /* ---------- feedback ---------- */
  let feedbackKind = "bug";

  function feedbackContext() {
    const theme = document.body.classList.contains("light") ? "Light" : "Dark";
    const platform = window.focusApp ? "Windows desktop app" : "Web app";
    return `App: PureStudy ${APP_VERSION}\nPlatform: ${platform}\nTheme: ${theme}`;
  }

  function feedbackReport() {
    const details = String(el.feedbackText.value || "").replace(/\r\n/g, "\n").trim().slice(0, 1500);
    if (!details) {
      toast("Add a few details before sending.");
      el.feedbackText.focus();
      return null;
    }
    const summary = String(el.feedbackTitle.value || "").replace(/\s+/g, " ").trim().slice(0, 80);
    const fallback = details.split("\n")[0].replace(/\s+/g, " ").trim().slice(0, 64);
    const label = feedbackKind === "feature" ? "Feature request" : "Bug report";
    const prefix = feedbackKind === "feature" ? "[Feature]" : "[Bug]";
    const title = `${prefix} ${summary || fallback || label}`.slice(0, 120);
    const lines = [
      feedbackKind === "feature" ? "### What I'd like" : "### What happened",
      details
    ];
    if (el.feedbackInclude && el.feedbackInclude.checked) {
      lines.push("", "---", "### App details", feedbackContext());
    }
    return { title, body: lines.join("\n"), kind: feedbackKind };
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(text);
        return;
      } catch (e) {}
    }
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    try {
      if (!document.execCommand("copy")) throw new Error("copy failed");
    } finally {
      ta.remove();
    }
  }

  el.feedbackKinds.forEach(btn => {
    btn.addEventListener("click", () => {
      feedbackKind = btn.dataset.kind === "feature" ? "feature" : "bug";
      el.feedbackKinds.forEach(b => {
        const on = b === btn;
        b.classList.toggle("active", on);
        b.setAttribute("aria-pressed", on ? "true" : "false");
      });
      el.feedbackTitle.placeholder = feedbackKind === "feature"
        ? "e.g. Add a daily notes view"
        : "e.g. Timer button stops working";
      el.feedbackTitle.focus();
    });
  });

  if (el.feedbackSend) {
    el.feedbackSend.addEventListener("click", () => {
      const report = feedbackReport();
      if (!report) return;
      const labels = report.kind === "feature" ? "enhancement" : "bug";
      const url = `${FEEDBACK_REPO}/issues/new?title=${encodeURIComponent(report.title)}&body=${encodeURIComponent(report.body)}&labels=${labels}`;
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast(window.focusApp ? "Opening GitHub in your browser…" : "Opening a GitHub report draft…");
    });
  }

  if (el.feedbackCopy) {
    el.feedbackCopy.addEventListener("click", async () => {
      const report = feedbackReport();
      if (!report) return;
      const text = `Title: ${report.title}\n\n${report.body}`;
      try {
        await copyText(text);
        toast("Report copied — paste it wherever you like.");
      } catch (e) {
        toast("Couldn't copy. Select the report text and copy it manually.");
      }
    });
  }

  if (el.feedbackLink) {
    el.feedbackLink.addEventListener("click", () => {
      switchTab("settings");
      setTimeout(() => {
        const card = $("feedbackCard");
        if (card) card.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 60);
    });
  }

  el.resetAll.addEventListener("click", () => {
    if (!confirm("Delete all XP, streaks, settings, tasks, journal entries and mind-map notes?")) return;
    localStorage.removeItem(KEY);
    S = defaults();
    clearInterval(tick);
    tick = null;
    endAt = 0;
    extSend("timer-cancel", { reason: "wipe" });
    Music.stop();
    paintMusic(null);
    closeNoteEditor();
    hydrate();
    paint();
    paintSettings();
    paintPetChoices();
    paintJournal();
    mapHydrate();
    applyAppearance();
    save();
    toast("Wiped. Fresh start.");
  });

  document.addEventListener("keydown", ev => {
    markActive();
    if (ev.code !== "Space") return;
    if ($("panel-mindmap").classList.contains("active")) return;
    const tag = (ev.target.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "button") return;
    ev.preventDefault();
    toggleTimer();
  });

  document.addEventListener("pointerdown", markActive, true);

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      if (S.timer.running) {
        const rem = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
        if (rem <= 0) { clearInterval(tick); tick = null; S.timer.running = false; complete(); }
        else { S.timer.remaining = rem; paint(); }
      } else {
        paint();
      }
    }
  });

  window.addEventListener("beforeunload", () => {
    if (skipUnloadSave) return;
    if (S.timer.running) {
      S.timer.remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
    }
    save();
  });

  // keep the day/streak honest if the app stays open past midnight
  setInterval(() => { rollDay(); paint(); }, 60000);

  // Your buddy says something new now and then while you work
  setInterval(() => {
    if (S.timer.running && !buddyHoldTimer) el.buddyLine.textContent = defaultBuddy();
  }, 45000);

  /* ============================ init ============================ */
  function hydrate() {
    paintTodos();
    el.setWork.value = S.settings.work;
    el.setShort.value = S.settings.short;
    el.setLong.value = S.settings.long;
    el.setBlocks.value = S.settings.blocks;
    el.setGoal.value = S.settings.dailyGoal;
    el.setAuto.checked = !!S.settings.auto;
    el.setSound.checked = !!S.settings.sound;
    el.setSoundStyle.value = S.settings.soundStyle;
    el.setVolume.value = S.settings.volume;
    el.volText.textContent = S.settings.volume + "%";
    el.setBuddy.checked = !!S.settings.buddy;
    if (el.setName) el.setName.value = S.settings.name || "";
    if (el.setExamName) el.setExamName.value = S.settings.examName || "";
    if (el.setExamDate) el.setExamDate.value = S.settings.examDate || "";
    el.musicVol.value = S.settings.musicVolume;
    el.musicVolText.textContent = S.settings.musicVolume + "%";
    paintJournal();
  }

  rollDay();
  // A session that was running when the tab closed is restored from its
  // wall-clock end time, so time spent elsewhere still counts.
  const restoredRunning = !!S.timer.running;
  const restoredEndAt = Number(S.timer.endAt) || 0;
  const restoredSessionId = S.timer.sessionId || "";
  S.timer.running = false;
  S.timer.endAt = 0;
  S.timer.sessionId = "";
  if (restoredRunning && restoredEndAt) {
    S.timer.remaining = restoredEndAt > Date.now()
      ? Math.max(1, Math.ceil((restoredEndAt - Date.now()) / 1000))
      : 0;
  } else if (!S.timer.remaining || S.timer.remaining <= 0) {
    S.timer.remaining = durationOf(S.timer.mode) * 60;
  }
  hydrate();
  paint();
  paintSettings();
  paintMusic(null);
  mapHydrate();
  buildLogoGrid();
  buildPetGrid();
  bindAppearance();
  applyAppearance();
  initOnboarding();
  markActive();
  extSend("timer-visit");
  if (restoredRunning && restoredEndAt) {
    if (restoredEndAt > Date.now()) {
      run(restoredEndAt, restoredSessionId);
    } else {
      complete();
    }
  } else {
    save();
  }
})();